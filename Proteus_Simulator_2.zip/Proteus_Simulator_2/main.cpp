#include "FEHLCD.h"
#include "FEHUtility.h"
#include "FEHRandom.h"
#include "FEHImages.h"
#include <string.h>
#include <math.h>
#include <fstream>
#include <iostream>
#include <vector>
#include <FEHRandom.h>
using namespace std;


void Menu();
void Play(float m);
void selectRegion(int* r);
void Stats(float m, int f, int d, int h, int v, int r);
void Rule(int page);
void Credits();
void ClearScreen();
void drawInstruction(int page);
bool collision(int x11, int x12, int y11, int y12, int x21, int x22, int y21, int y22, int r);
void drawBackground(int BGnum);
void drawFishPond(char* pond,int x,int y);
void drawFishRiver(char* river, int x,int y);
void drawFishSea(char* sea,int x,int y);
void drawArrow(int d, int x, int y);
void collection(int page);
void pondCollection();
void riverCollection();
void seaCollection();
void drawHome(int x, int y);

/*
    SDP 4
    Making a main menu​
*/
void Menu() {
    //set variables
    float x_position, y_position, x_trash, y_trash;
    float money = 0;
    int fish = 0, descentLevel = 1, horizontalLevel = 1, valueLevel = 1, region = 1;
    FEHImage play;
    
    while(1) {
        //clear screen
        //ClearScreen();
        drawBackground(0);
        // FEHImage tilapia;
        // tilapia.Open("TilapiaFEH.pic");
        // tilapia.Draw(0,0);
        // tilapia.Close();
        LCD.SetFontColor(BLACK);
        //display main menu middle top screen
        LCD.WriteAt("Fishing", 15, 31);
        LCD.WriteAt("SIM", 90, 61);
        //LCD.WriteAt("Play Game", 10, 111);
        play.Open("Play-ButtonFEH.pic");
        play.Draw(35, 101);
        play.Close();
        LCD.WriteAt("Statistics", 5, 131);
        LCD.WriteAt("How to Play", 2, 151);
        LCD.WriteAt("Collection",5,171);
        LCD.WriteAt("Credits", 25, 191);

        

        Sleep(.5);
        //clear touch buffer
        LCD.ClearBuffer();
        //wait till user touches the screen
        while(!LCD.Touch(&x_position, &y_position)) {}
        //wait until the touch releases
        while(LCD.Touch(&x_trash, &y_trash)) {}
        //check which option the user pressed
        if((x_position >= 35 && x_position <= 90) && (y_position >= 101 && y_position <=121)) {
            //width = 106 px
            //clear the screen
            ClearScreen();
            //play game menu
            Play(money);
        }
        else if((x_position >= 5 && x_position <= 124) && (y_position >= 131 && y_position <=146)) {
            //clear the screen
            ClearScreen();
            //display game stats
            Stats(money, fish, descentLevel, horizontalLevel, valueLevel, region);
        }
        else if((x_position >= 2 && x_position <= 132) && (y_position >= 151 && y_position <=166)) {
            //clear the screen
            ClearScreen();
            //display instructions
            Rule(1);
        }
        else if((x_position >= 5 && x_position <= 102) && (y_position >= 171 && y_position <=186)) {
            //clear the screen
            ClearScreen();
            //collection
            collection(1);
        }
        else if((x_position >= 25 && x_position <= 106) && (y_position >= 191 && y_position <=206)) {
            //clear the screen
            ClearScreen();
            //display credits
            Credits();
        }
        else {
            Menu();
        }
    }
}
void Play(float money) {
    //declare variables for touch
    float x_position, y_position, x_trash, y_trash, bobber_x=155, bobber_y=0,curTime;
    int fishSize = 12;

    char pondFish[12][50] = {"M_Carp_FEH.pic", "M_Catfish_FEH.pic", "S_Crawfish_FEH.pic", "S_Frog_FEH.pic", "L_Gar_FEH.pic", "M_Giant_Snakehead_FEH.pic", "S_Goldfish_FEH.pic", "S_Killifish_FEH.pic", "M_Koi_FEH.pic", "S_Pop-Eyed_Goldfish_FEH.pic", "S_Ranchu_Goldfish_FEH.pic", "S_Tadpole_FEH.pic"};
    int pondPrice[] = {300, 800, 200, 120, 6000, 5500, 1300, 300, 4000, 1300, 4500, 100};
    char riverFish[15][50] = {"S_Angelfish_FEH.pic", "L_Arapaima_FEH.pic", "M_Arowana_FEH.pic", "S_Betta_FEH.pic", "L_Dorado_FEH.pic", "S_Freshwater_Goby_FEH.pic", "M_Golden_Trout_FEH.pic", "S_Neon_FEH.pic", "S_Pale_Chub_FEH.pic", "S_Piranha_FEH.pic", "M_Saddled_FEH.pic", "M_Salmon_FEH.pic", "M_Snapping_Turtle_FEH.pic", "L_Sturgeon_FEH.pic", "M_Tilapia_FEH.pic"};
    int riverPrice[] = {3000, 10000, 10000, 2500, 15000, 400, 15000, 500, 200, 2500, 4000, 700, 5000, 10000, 800};
    char seaFish[15][50] = {"M_Blowfish_FEH.pic", "S_Butterfly_Fish_FEH.pic", "S_Clown_Fish_FEH.pic", "L_Coelacanth_FEH.pic", "M_Dab_FEH.pic", "L_Great_White_Shark_FEH.pic", "L_Napoleonfish_FEH.pic", "L_Ocean_Sunfish_FEH.pic", "M_Red_Snapper_FEH.pic", "L_Saw_Shark_FEH.pic", "S_Sea_Horse_FEH.pic", "M_Squid_FEH.pic", "L_Suckerfish_FEH.pic", "S_Surgeonfish_FEH.pic", "L_Whale_Shark_FEH.pic"};
    int seaPrice[] = {5000, 1000, 650, 15000, 300, 15000, 10000, 4000, 3000, 12000, 500, 500, 1500, 1000, 1300};
   

    int region;
    //select region screen
    selectRegion(&region);
    //draw backgroud of region
    drawBackground(region);
    //set counter variables
    int maxL = 2, l = 0, maxM = 4, m = 0;
    int yStart = 110, xStart = 20, xEnd = 320, yEnd = 230;
    int fish[fishSize], limit = 15;
    int width[fishSize];
    //only 12 fishes in pond
    if(region == 1) {
        limit = 12;
    }
    //get name
    char name[50];
    for(int i = 0; i < fishSize; i++) {
        //randomly generate fish
        fish[i] = Random.RandInt()%limit;
        //get fish name from different region
        if(region == 1) {
            strcpy(name, pondFish[fish[i]]);
        }
        else if(region == 2) {
            strcpy(name, riverFish[fish[i]]);
        }
        else if(region == 3) {
            strcpy(name, seaFish[fish[i]]);
        }
        //get the size of the fish
        if(name[0] == 'S') {
            width[i] = 20;
        }
        else if(name[0] == 'M') {
            //limit number of medium fishes, so the game can fit more fish
            m++;
            width[i] = 30;
            if(m > maxM) {
                i--;
            }
        }
        else if(name[0] == 'L') {
            //limit number of large fishes, so the game can fit more fish
            l++;
            width[i] = 45;
            if(l > maxL) {
                i--;
            }
        }
    }

    //declare and initialize counter variables
    int xyStart[fishSize][2];
    int xyEnd[fishSize][2];
    bool fit;
    int x1, x2, y1, y2, num =0, buffer = 10, distance, xCenter1, xCenter2, yCenter1, yCenter2, r;
    //randomly generated x and y coordinates of each fish
    while(num < fishSize) {
        //generate random coordinate
        x1 = xStart + Random.RandInt()%(xEnd-width[num]-xStart+1);
        x2 = x1 + width[num];
        y1 = yStart + Random.RandInt()%(yEnd-width[num]-yStart+1);
        y2 = y1 + width[num];
        //LCD.SetFontColor(BLACK);
        //LCD.DrawRectangle(x1, y1, width[num], width[num]);
        fit = true;

        //check that the fish will not overlap with previous fish
        for(int n = 0; n < num && fit; n++){
            if(width[n] > width[num]) {
                r = width[n];
            }
            else {
                r = width[num];
            }
            //if both coordinate collide, then the fish overlap
            if (collision(x1, x2, y1, y2, xyStart[n][0], xyEnd[n][0], xyStart[n][1], xyEnd[n][1], r)) {
                fit = false;
            }
        }
        //the fish coordinate cannot be more/less than the grid
        if(x1 < xStart || x2 > xEnd) {
            fit = false;
        }
        if(y1 < yStart || y2 > yEnd) {
            fit = false;
        }

        //if the coordinate meet all above requirement, store it as a pair of coordinate
        if(fit) {
            xyStart[num][0] = x1;
            xyStart[num][1] = y1;
            xyEnd[num][0] = x2;
            xyEnd[num][1] = y2;
            num++;
        }
    }

    //print click to start
    LCD.SetFontColor(BLACK);
    LCD.WriteAt("Click to start", 80, 111);

    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    

    FEHImage bobber;
    bobber.Open("bobber2FEH.pic");
    bobber.Draw(bobber_x,bobber_y);
    Sleep(.5);
    //clear touch buffer
    LCD.ClearBuffer();
    /*move bobber down over time while also looking for user input*/
    while(bobber_y<220){

        drawBackground(region);

        //draw the fish from different region in randomly generated coordinate pairs
        for(int i = 0; i < fishSize; i++) {
            if(region == 1) {
                drawFishPond(pondFish[fish[i]], xyStart[i][0], xyStart[i][1]);
            }
            else if(region == 2) {
                drawFishRiver(riverFish[fish[i]], xyStart[i][0], xyStart[i][1]);
            }
            else if(region == 3) {
                drawFishSea(seaFish[fish[i]], xyStart[i][0], xyStart[i][1]);
            }
        }

        //if screen touched, move left or right
        if(LCD.Touch(&x_position, &y_position)){
            //maybe drawbackground function here? or fish?

            //if user touches to the right of bobber, move right. if user touches to
            //the left, move left
            if(x_position>=bobber_x){
                //should replace value with users horizontal speed value
                bobber_x+=.5;
            }else if(x_position<bobber_x){
                bobber_x-=.5;
            }
        }
        //amount added should be replaced with descent speed
        bobber_y+=.5;
        bobber.Draw(bobber_x,bobber_y);
        //draw the fishing line
        LCD.DrawLine(bobber_x+4,0,bobber_x+4,bobber_y);
        Sleep(.001);
        LCD.ClearBuffer();
    }
    //display a results screen
    LCD.SetFontColor(BLACK);
    LCD.FillRectangle(40,40,240,160);
    LCD.SetFontColor(WHITE);
    LCD.WriteAt("No fish Caught",40,41);
    LCD.WriteAt("Money Gained: ",40,66);
    LCD.SetFontColor(GREEN);
    LCD.WriteAt(money,210,65);
    LCD.SetFontColor(WHITE);
    //sleep for 2 seconds so that the results screen is not skipped
    Sleep(2.0);
    LCD.ClearBuffer();
    //this creates a click to continue once the bobber movement loop has been completed.
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}

    //this is for the placeholder play game screen
    /*
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    //return to main menu
    if((x_position >= 40 && x_position <= 270) && (y_position >= 210 && y_position <=220)) {
        bobber.Close();
        printf("bobber closed");
        Menu();
    }
    else{
        printf("moved");
        //ClearScreen();
        bobber_x +=10;
        Play();
    }
    */
}

bool collision(int x11, int x12, int y11, int y12, int x21, int x22, int y21, int y22, int r){
    int xCenter1 = (x11+x12)/2;
    int yCenter1 = (y11+y12)/2;
    int xCenter2 = (x21 + x22)/2;
    int yCenter2 = (y21 + y22)/2;

    return abs(xCenter1 - xCenter2) < r && abs(yCenter1 - yCenter2) < r;
}
void selectRegion(int* region) {
    //declare variables for touch
    float x_position, y_position, x_trash, y_trash;
    drawBackground(0);

    //print click to start
    LCD.SetFontColor(BLACK);
    LCD.WriteAt("Select", 15, 31);
    LCD.WriteAt("Region", 60, 56);
    LCD.WriteAt("Pond", 41, 121);
    LCD.WriteAt("River", 37, 151);
    LCD.WriteAt("Sea", 45, 181);
    drawHome(280, 200);

    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}

    //return to main menu
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        Menu();
    }
    else if((x_position >= 41 && x_position <= 88) && (y_position >= 121 && y_position <=136)){
        //stay in stats
        *region = 1;
    }
    else if((x_position >= 37 && x_position <= 98) && (y_position >= 151 && y_position <=166)) {
        *region = 2;
    }
    else if((x_position >= 45 && x_position <= 82) && (y_position >= 181 && y_position <=196)) {
        *region = 3;
    }
    else {
        selectRegion(region);
    }

}
void Stats(float money, int fish, int descentLevel, int horizontalLevel, int valueLevel, int region) {
    //declare variables for touch
    float x_position, y_position, x_trash, y_trash;
    //display all the stats
    LCD.SetFontColor(WHITE);
    LCD.WriteAt("Statistics", 90, 5);
    LCD.WriteAt("Money: $", 40, 50);
    LCD.SetFontColor(GREEN);
    LCD.WriteAt(money, 150, 50);
    LCD.SetFontColor(WHITE);
    LCD.WriteAt("Fish caught: ", 40, 70);
    LCD.WriteAt(fish, 190, 70);
    LCD.WriteAt("Descent Level: ", 40, 90);
    LCD.WriteAt(descentLevel, 210, 90);
    LCD.WriteAt("Speed Level: ", 40, 110);
    LCD.WriteAt(horizontalLevel, 190, 110);
    LCD.WriteAt("Value x: ", 40, 130);
    LCD.WriteAt(valueLevel, 150, 130);
    LCD.WriteAt("Region: ", 40, 150);
    LCD.WriteAt(region, 130, 150);
    drawHome(280, 200);

    Sleep(.5);
    //clear touch buffer
    LCD.ClearBuffer();
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    //return to main menu
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        Menu();
    }
    else {
        //stay in stats
        Stats(money, fish, descentLevel, horizontalLevel, valueLevel, region);
    }
}
void Rule(int page) {
    //declare variable for touch
    float x_position, y_position, x_trash, y_trash;
    int nextXPos=225,previousXPos=40;
    //this was causing it to print instructions in the terminal? weird
    //printf(page + "\n");
    LCD.SetFontColor(WHITE);
    LCD.WriteAt("How to Play", 90, 5);
    drawHome(280, 200);
    //font color blue to differentiate buttons
    LCD.SetFontColor(BLUEVIOLET);
    if(page < 3) {
        //LCD.WriteAt("Next",nextXPos,190);
        drawArrow(2, nextXPos, 190);
    }
    if(page > 1){
        //LCD.WriteAt("Back",previousXPos,180);
        drawArrow(1, previousXPos, 190);
    }
    //clear any instructions that were on screen
    //LCD.SetFontColor(BLACK);
    //drawInstruction(page-1);
    //LCD.SetFontColor(BLACK);
    //drawInstruction(page+1);
    //display current page of instructions
    LCD.SetFontColor(WHITE);
    drawInstruction(page);
    Sleep(.5);
    //clear touch buffer
    LCD.ClearBuffer();
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    //return to main menu
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        Menu();
    }else if((x_position>=nextXPos && x_position<=nextXPos+29)&&(y_position>=190 && y_position<=217)&&(page<3)){
        //increment page number IF click within region and if maximum page is not reached
        page++;
        ClearScreen();
        Rule(page);
    }else if((x_position>=previousXPos && x_position<=previousXPos+29)&&(y_position>=190 && y_position<=217)&&(page>1)){
        //decrement page number IF click within region and if minimum page is not reached
        page--;
        ClearScreen();
        Rule(page);
    }else {
        Rule(page);
    }
}
void collection(int page) {
    //declare variable for touch
    float x_position, y_position, x_trash, y_trash;
    int nextXPos=260,previousXPos=15;
    drawBackground(page);
    //this was causing it to print instructions in the terminal? weird
    //printf(page + "\n");
    LCD.SetFontColor(BLACK);
    drawHome(280, 200);
    //font color blue to differentiate buttons
    LCD.SetFontColor(BLUEVIOLET);
    if(page < 3) {
        LCD.WriteAt("Next",nextXPos,5);
    }
    if(page > 1){
        LCD.WriteAt("Back",previousXPos,5);
    }
    
    LCD.SetFontColor(BLACK);
    switch (page)
    {
    case 1:
        pondCollection();
        break;
    case 2:
        riverCollection();
        break;
    case 3:
        seaCollection();
        break;
    
    default:
        break;
    }

    Sleep(.5);
    //clear touch buffer
    LCD.ClearBuffer();
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    //return to main menu
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        Menu();
    }else if((x_position>=nextXPos && x_position<=nextXPos+50)&&(y_position>=5 && y_position<=20)&&(page<3)){
        //increment page number IF click within region and if maximum page is not reached
        page++;
        ClearScreen();
        collection(page);
    }else if((x_position>=previousXPos && x_position<=previousXPos+50)&&(y_position>=5 && y_position<=20)&&(page>1)){
        //decrement page number IF click within region and if minimum page is not reached
        page--;
        ClearScreen();
        collection(page);
    }else {
        collection(page);
    }
}
void pondCollection() {
    LCD.WriteAt("POND", 140, 5);
    int num = 1, x = 15, y = 110;
    for(int i = 0; i < 3; i++) {
        //drawFishPond(num, x, y);
        num++;
        y += 30;
    }
    x+= 80;
    y=110;
    for(int i = 0; i < 3; i++) {
        //drawFishPond(num, x, y);
        num++;
        y += 30;
    }

    x+= 80;
    y=110;
    for(int i = 0; i < 3; i++) {
        //drawFishPond(num, x, y);
        num++;
        y += 30;
    }

    x+= 80;
    y=110;
    for(int i = 0; i < 3; i++) {
        //drawFishPond(num, x, y);
        num++;
        y += 30;
    }
    
}

void seaCollection() {
    LCD.WriteAt("SEA", 145, 5);
}

void riverCollection() {
    LCD.WriteAt("RIVER", 130, 5);
}

void Credits() {
    //declare variables for touch
    float x_position, y_position, x_trash, y_trash;
    //display developer names
    LCD.SetFontColor(WHITE);
    LCD.WriteAt("Developers", 94, 31);
    LCD.WriteAt("Evan Davis", 94, 91);
    LCD.WriteAt("JJ Kiratikosolrak", 60, 121);
    drawHome(280, 200);
    Sleep(.5);
    //clear touch buffer
    LCD.ClearBuffer();
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    //return to main menu
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        Menu();
    }
    else {
        Credits();
    }
}
void drawHome(int x, int y) {
    FEHImage home;
    home.Open("homeFEH.pic");
    home.Draw(x, y);
    home.Close();
}
void ClearScreen() {
    // Clear background
    LCD.SetBackgroundColor(BLACK);
    LCD.Clear();
    LCD.Update();
    // LCD.SetFontColor(BLACK);
    // LCD.FillRectangle(0, 0, 319, 239);
    // LCD.SetFontColor(WHITE);
    // LCD.Update();
}
void drawInstruction(int page){
    //print the instructions for the corresponding page. starts at y=30 and goes to y=165
    //i love no auto wraparound text!
    //15 pixel line spacing
    switch(page){
        case 1:
            LCD.WriteAt("To play, touch play on",10,30);
            LCD.WriteAt("the main menu. Your goal",10,45);
            LCD.WriteAt("is to guide the bobber to",10,60);
            LCD.WriteAt("a fish before the time",10,75);
            LCD.WriteAt("runs out or the bobber",10,90);
            LCD.WriteAt("reaches the bottom. You",10,105);
            LCD.WriteAt("will receive more money",10,120);
            LCD.WriteAt("depending on how much",10,135);
            LCD.WriteAt("the fish is worth. More",10,150);
            LCD.WriteAt("valuable fish are below.",10,165);
            LCD.WriteAt("1",145,195);
            break;
        case 2:
            LCD.WriteAt("You will accumulate money",10,30);
            LCD.WriteAt("over time, which can be",10,45);
            LCD.WriteAt("spent on various upgrades.",10,60);
            LCD.WriteAt("Upgrades increase the",10,75);
            LCD.WriteAt("speed of descent, the",10,90);
            LCD.WriteAt("horizontal speed, the",10,105);
            LCD.WriteAt("value of fish, and the",10,120);
            LCD.WriteAt("area you are in. Upgrades",10,135);
            LCD.WriteAt("get more expensive as",10,150);
            LCD.WriteAt("they are purchased.",10,165);
            LCD.WriteAt("2",145,195);
            break;
        case 3:
            LCD.WriteAt("Every unique fish that is",10,30);
            LCD.WriteAt("caught is added to a",10,45);
            LCD.WriteAt("collection which can be ",10,60);
            LCD.WriteAt("viewed from the menu.",10,75);
            LCD.WriteAt("Each fish has its own",10,90);
            LCD.WriteAt("entry with information",10,105);
            LCD.WriteAt("and facts about it.",10,120);
            LCD.WriteAt(" ",10,135);
            LCD.WriteAt(" ",10,150);
            LCD.WriteAt(" ",10,165);
            LCD.WriteAt("3",145,195);
            break;
    }
}
/*by Evan D. This function takes an integer input for a corresponding background image
1 is main menu background, 2 is sea/beach background, 3 is pond background, 4 is
river background*/
void drawBackground(int BGnum){
    FEHImage BG;
    switch(BGnum){
        case 0:
            BG.Open("mainFEH.pic");
            break;
        case 1:
            BG.Open("Pond-bgFEH.pic");
            break;
        case 2:
            BG.Open("River-bgFEH.pic");
            break;
        case 3:
            BG.Open("Beach-bgFEH.pic");
            break;
    }
    BG.Draw(0,0);
    BG.Close();
}
/* by Evan D. Takes 3 integer inputs, 1 for the fish image to draw and the other two are the coordinates to draw at.
The integers that correspond to fish are listed in each element of the switch case. */
void drawFishPond(char* pond,int x,int y){
    FEHImage Fish;
    Fish.Open(pond);
    Fish.Draw(x,y);
    Fish.Close();
}
void drawFishRiver(char* river, int x,int y){
    FEHImage Fish;
    Fish.Open(river);
    Fish.Draw(x,y);
    Fish.Close();
}
void drawFishSea(char* sea,int x,int y){
    FEHImage Fish;
    Fish.Open(sea);
    Fish.Draw(x,y);
    Fish.Close();
}
void drawArrow(int d, int x, int y) {
    //22x26
    FEHImage arrow;
    if(d == 1){
        arrow.Open("arrow-leftFEH.pic");
    }
    else if(d==2) {
        arrow.Open("arrow-rightFEH.pic");
    }
    arrow.Draw(x, y);
    arrow.Close();
}
int main() {
    // Clear background
    LCD.SetBackgroundColor(BLACK);
    LCD.Clear();
    Menu();
    while (1) {
        LCD.Update();
        // Never end
    }
    return 0;
}