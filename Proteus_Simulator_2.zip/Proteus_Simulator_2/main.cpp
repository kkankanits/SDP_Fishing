#include "FEHLCD.h"
#include "FEHUtility.h"
#include "FEHRandom.h"
#include "FEHImages.h"
#include <string.h>
#include <math.h>
#include <fstream>
#include <iostream>
#include <vector>
#include <FEHRandom.h>
using namespace std;

/*this class creates a way to access and change the users values. a single variable can be created with this class
and can be passed by reference to all functions where it will be used.*/
class userStats{
    public:
        userStats(int m = 0, int f = 0, int d = 1, int h = 1, int v = 1);
        int getLevel(char which);
        void changeLevel(char level, int amount);
        void incrementFish();
        int getMoney();
        int getFishCaught();
        int getDescentLevel();
        int getHorizontalLevel();
        int getValue();
        void resetStats();

    private:
        int money, fishCaught, descentLevel, horizontalLevel, value;
};

/*by Evan D. this function initializes the values within the class.*/
userStats::userStats(int m, int f, int d, int h, int v){
    //constructor; initialize values of money and levels
    money=m;
    fishCaught=f;
    descentLevel=d;
    horizontalLevel=h;
    value=v;
}

/*by Evan D. this function returns the value of the users stats depending on a char input. input chars are as follows: m is for money, d is for 
descentLevel, h is for horizontalLevel, and v is for verticalLevel*/
int userStats::getLevel(char level){
    switch(level){
        case 'm':
            return money;
            break;
        case 'd':
            return descentLevel;
            break;
        case 'h':
            return horizontalLevel;
            break;
        case 'v':
            return value;
            break;
    }
}

/*by JJ K. this function increment the number of fish caught.*/
void userStats::incrementFish(){
    fishCaught++;
}

/*by JJ K. this function increment the number of fish caught.*/
int userStats::getMoney(){
    return money;
}

/*by JJ K. this function returns the descent level value*/
int userStats::getDescentLevel() {
    return descentLevel;
}

/*by JJ K. this function return the number of fish caught*/
int userStats::getFishCaught() {
    return fishCaught;
}

/*by JJ K. this function return the horizontal level value*/
int userStats::getHorizontalLevel() {
    return horizontalLevel;
}

/*by JJ K. this function return the fish value*/
int userStats::getValue() {
    return value;
}

/*by JJ K. this function resets the stats to initial value*/
void userStats::resetStats(){
    money=0;
    fishCaught=0;
    descentLevel=1;
    horizontalLevel=1;
    value=1;
}

/*by Evan D. this function changes the values within a class. it takes a char input which corresponds
to the value it will change by the int input amount. input chars are as follows: m is for money, d is for 
descentLevel, h is for horizontalLevel, and v is for verticalLevel*/
void userStats::changeLevel(char level, int amount){
    switch(level){
        case 'm':
            money+=amount;
            break;
        case 'd':
            descentLevel+=amount;
            break;
        case 'h':
            horizontalLevel+=amount;
            break;
        case 'v':
            value+=amount;
            break;
    }
}

//declare all function prototypes
void Menu(userStats &user);
void Play(userStats &user, int r);
void selectRegion(int* r, userStats &user);
void Stats(userStats &user, int f);
void Rule(int page, userStats &user);
void Credits(userStats &user);
void drawInstruction(int page);
bool collision(int x11, int x12, int y11, int y12, int x21, int x22, int y21, int y22, int r);
void drawBackground(int BGnum);
void drawFishPond(char* pond,int x,int y);
void drawFishRiver(char* river, int x,int y);
void drawFishSea(char* sea,int x,int y);
void drawArrow(int d, int x, int y);
void collection(int region, int page, userStats &user);
void selectCollection(int* region, userStats &user);
void pondCollection(int page);
void riverCollection(int page);
void seaCollection(int page);
void getPondName(int fishNum, int x, int y);
void getRiverName(int fishNum, int x, int y);
void getSeaName(int fishNum, int x, int y);
void drawHome(int x, int y);
void drawBack(int x, int y);
void drawReplay(int x, int y);
void drawMoney(int x, int y);
void drawResultScreen(int region, int whichFish, userStats &user, int price[], int fish[], char* name, int w);
void recordFishCaught(int region, int fishNum);
void recordStats(userStats &user);
void getWidth(char name[][50], int* width, int size);
bool checkFishCaught(int region, int fishNum);
void drawSetting(int x, int y);
void setSettingScreen(userStats &user);

/*by Evan D and JJ K. this function draws the main menu and call other functions based on where the user touched the screen*/
void Menu(userStats &user) {
    //set variables for touch
    float x_position, y_position, x_trash, y_trash;
    //declare variable
    int fish = 0, descentLevel = 1, horizontalLevel = 1, valueLevel = 1, region = 1;
    FEHImage play;
    
    //never end
    while(1) {
        //draw main menu background
        drawBackground(0);
        
        //write options of main menu
        LCD.SetFontColor(BLACK);
        LCD.WriteAt("Fishing", 20, 31);
        LCD.WriteAt("Fishing", 21, 32);
        LCD.WriteAt("SIM", 43, 61);
        LCD.WriteAt("SIM", 44, 62);
        play.Open("Play-ButtonFEH.pic");
        play.Draw(35, 101);
        play.Close();
        LCD.WriteAt("Statistics", 5, 131);
        LCD.WriteAt("How to Play", 2, 151);
        LCD.WriteAt("Collection",5,171);
        LCD.WriteAt("Credits", 25, 191);
        drawSetting(270, 190);

        
        //update the screen
        Sleep(.01);
        //clear touch buffer
        LCD.ClearBuffer();
        //wait till user touches the screen
        while(!LCD.Touch(&x_position, &y_position)) {}
        //wait until the touch releases
        while(LCD.Touch(&x_trash, &y_trash)) {}

        //check which option the user pressed
        if((x_position >= 35 && x_position <= 90) && (y_position >= 101 && y_position <=121)) {
            //play game menu
            selectRegion(&region, user);
        }
        else if((x_position >= 5 && x_position <= 124) && (y_position >= 131 && y_position <=146)) {
            //display game stats
            Stats(user, fish);
        }
        else if((x_position >= 2 && x_position <= 132) && (y_position >= 151 && y_position <=166)) {
            //display instructions
            Rule(1, user);
        }
        else if((x_position >= 5 && x_position <= 125) && (y_position >= 171 && y_position <=186)) {
            //display collection
            selectCollection(&region, user);
        }
        else if((x_position >= 25 && x_position <= 108) && (y_position >= 191 && y_position <=206)) {
            //display credits
            Credits(user);
        }
        else if((x_position >= 270 && x_position <= 300) && (y_position >= 190 && y_position <=220)) {
            //display setting
            setSettingScreen(user);
        }
        else {
            //remain in main menu
            Menu(user);
        }
        //record stats in text file
        recordStats(user);
    }
}
/*by Evan D and JJ K. this function sets up the play cycle for the user, which consists of a few steps.
first, draw background according to the region user's pick. 
second, random coordinates for the fish will be chosen and checked to make sure each fish' size does not overlap with another.
then the fish and bobber will be drawn 
the bobber will then move down the screen while looking for user input on either side of it, as
well as making sure the bobber is not at the bottom of the screen or has collided with a fish. the drawing process is 
repeated after each check
each fish also move across the screen
Once the bobber reach the bottom of the screen or a fish has been caught, the result screen is called.*/
void Play(userStats &user, int region) {
    //declare variables for touch
    float x_position, y_position, x_trash, y_trash, bobber_x=155, bobber_y=0,curTime;
    //declare variable
    int fishSize = 10, whichFish=-1;
    bool fishCaught=false;

    //declare and initialize fishes and their price
    char pondFish[12][50] = {"M_Carp_FEH.pic", "M_Catfish_FEH.pic", "S_Crawfish_FEH.pic", "S_Frog_FEH.pic", "L_Gar_FEH.pic", "M_Giant_Snakehead_FEH.pic", "S_Goldfish_FEH.pic", "S_Killifish_FEH.pic", "M_Koi_FEH.pic", "S_Tadpole_FEH.pic", "S_Pop-Eyed_Goldfish_FEH.pic", "S_Ranchu_Goldfish_FEH.pic"};
    int pondPrice[] = {300, 800, 200, 120, 6000, 5500, 1300, 300, 4000, 1300, 4500, 100};
    char riverFish[15][50] = {"S_Angelfish_FEH.pic", "L_Arapaima_FEH.pic", "M_Arowana_FEH.pic", "S_Betta_FEH.pic", "L_Dorado_FEH.pic", "S_Freshwater_Goby_FEH.pic", "M_Golden_Trout_FEH.pic", "S_Neon_FEH.pic", "S_Pale_Chub_FEH.pic", "S_Piranha_FEH.pic", "M_Saddled_FEH.pic", "M_Salmon_FEH.pic", "M_Snapping_Turtle_FEH.pic", "L_Sturgeon_FEH.pic", "M_Tilapia_FEH.pic"};
    int riverPrice[] = {3000, 10000, 10000, 2500, 15000, 400, 15000, 500, 200, 2500, 4000, 700, 5000, 10000, 800};
    char seaFish[15][50] = {"M_Blowfish_FEH.pic", "S_Butterfly_Fish_FEH.pic", "S_Clown_Fish_FEH.pic", "L_Coelacanth_FEH.pic", "M_Dab_FEH.pic", "L_Great_White_Shark_FEH.pic", "L_Napoleonfish_FEH.pic", "L_Ocean_Sunfish_FEH.pic", "M_Red_Snapper_FEH.pic", "L_Saw_Shark_FEH.pic", "S_Sea_Horse_FEH.pic", "M_Squid_FEH.pic", "L_Suckerfish_FEH.pic", "S_Surgeonfish_FEH.pic", "L_Whale_Shark_FEH.pic"};
    int seaPrice[] = {5000, 1000, 650, 15000, 300, 15000, 10000, 4000, 3000, 12000, 500, 500, 1500, 1000, 1300};
   

    //draw backgroud of region
    drawBackground(region);

    //set counter variables
    int maxL = 2, l = 0, maxM = 4, m = 0;
    int yStart = 110, xStart = 20, xEnd = 320, yEnd = 230;
    int fish[fishSize], limit = 15;
    int width[fishSize];

    //only 12 fishes in pond
    if(region == 1) {
        limit = 12;
    }

    //get name
    char name[50];
    for(int i = 0; i < fishSize; i++) {
        //randomly generate fish
        fish[i] = Random.RandInt()%limit;
        //get fish name from different region
        if(region == 1) {
            strcpy(name, pondFish[fish[i]]);
        }
        else if(region == 2) {
            strcpy(name, riverFish[fish[i]]);
        }
        else if(region == 3) {
            strcpy(name, seaFish[fish[i]]);
        }
        //get the size of the fish
        if(name[0] == 'S') {
            width[i] = 20;
        }
        else if(name[0] == 'M') {
            //limit number of medium fishes, so the game can fit more fish
            m++;
            width[i] = 30;
            if(m > maxM) {
                i--;
            }
        }
        else if(name[0] == 'L') {
            //limit number of large fishes, so the game can fit more fish
            l++;
            width[i] = 45;
            if(l > maxL) {
                i--;
            }
        }
    }

    //declare and initialize coordinate variables
    int xyStart[fishSize][2];
    int xyEnd[fishSize][2];
    bool fit;
    int x1, x2, y1, y2, num =0, buffer = 10, distance, xCenter1, xCenter2, yCenter1, yCenter2, r;

    //randomly generated x and y coordinates of each fish
    while(num < fishSize) {
        //generate random coordinate
        x1 = xStart + Random.RandInt()%(xEnd-width[num]-xStart+1);
        x2 = x1 + width[num];
        y1 = yStart + Random.RandInt()%(yEnd-width[num]-yStart+1);
        y2 = y1 + width[num];
        //reset counter variable
        fit = true;

        //check that the fish will not overlap with previous fish
        for(int n = 0; n < num && fit; n++){
            if(width[n] > width[num]) {
                r = width[n];
            }
            else {
                r = width[num];
            }
            //if both coordinate collide, then the fish overlap
            if (collision(x1, x2, y1, y2, xyStart[n][0], xyEnd[n][0], xyStart[n][1], xyEnd[n][1], r)) {
                fit = false;
            }
        }

        //the fish coordinate cannot be more/less than the grid
        if(x1 < xStart || x2 > xEnd) {
            fit = false;
        }
        if(y1 < yStart || y2 > yEnd) {
            fit = false;
        }

        //if the coordinate meet all above requirement, store it as a pair of coordinate
        if(fit) {
            xyStart[num][0] = x1;
            xyStart[num][1] = y1;
            xyEnd[num][0] = x2;
            xyEnd[num][1] = y2;
            num++;
        }
    }

    //print click to start
    LCD.SetFontColor(BLACK);
    LCD.WriteAt("Click to start", 75, 130);

    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    
    //draw the bobber
    FEHImage bobber;
    bobber.Open("bobber2FEH.pic");
    bobber.Draw(bobber_x,bobber_y);
    Sleep(.5);

    //clear touch buffer
    LCD.ClearBuffer();

    /*move bobber down over time while also looking for user input*/
    while(bobber_y<220){
        //redraw the background
        drawBackground(region);

        //draw the fish from different region in its randomly generated coordinate pairs
        for(int i = 0; i < fishSize; i++) {

            if(region == 1) {
                drawFishPond(pondFish[fish[i]], xyStart[i][0], xyStart[i][1]);
            }
            else if(region == 2) {
                drawFishRiver(riverFish[fish[i]], xyStart[i][0], xyStart[i][1]);
            }
            else if(region == 3) {
                drawFishSea(seaFish[fish[i]], xyStart[i][0], xyStart[i][1]);
            }
        }

        //if screen touched, move left or right
        if(LCD.Touch(&x_position, &y_position)){
            //if user touches to the right of bobber, move right. if user touches to
            //the left, move left
            if(x_position>=bobber_x){
                //users horizontal speed level impacts how fast it will move
                //bobber_x+=.5*money[2];
                bobber_x+=.5*user.getLevel('h');
            }else if(x_position<bobber_x){
                //bobber_x-=.5*money[2];
                bobber_x-=.5*user.getLevel('h');
            }
        }
        //amount added should be replaced with descent speed
        bobber_y+=.5*user.getLevel('d');
        //draw the bobber
        bobber.Draw(bobber_x,bobber_y);
        //draw the fishing line
        LCD.DrawLine(bobber_x+4,0,bobber_x+4,bobber_y);
        Sleep(.01);
        LCD.ClearBuffer();

        //check collisions. fc is fish count
        for(int fc=0;fc<fishSize;fc++){
            /*if bobber collides with fish, set variable to exit while loop and exit for loop in case somehow collide with two fish
            radius is set to 10 in the collision check because the bobber is 10x10. can be changed if issues are found or if
            size changes*/
            //cout << bobber_x << " " << bobber_y << " " << xyStart[fc][0] << " " << xyEnd[fc][0] << " " << xyStart[fc][1] << " " << xyEnd[fc][1] << endl;
            if(collision(bobber_x,bobber_x+10,bobber_y,bobber_y+10, xyStart[fc][0], xyEnd[fc][0], xyStart[fc][1], xyEnd[fc][1], 10)){
                fishCaught=true;
                whichFish=fc;
                break;
            }
        }
        //break if a fish collides with bobber
        if(fishCaught){
            //increment fish count
            user.incrementFish();
            //record the fish caught
            recordFishCaught(region, fish[whichFish]);
            break;
        }
        //move the fish to the left
        for(int i = 0; i < fishSize; i++) {
            xyStart[i][0] -= 1;
            //reset x coordinate if it becomes negative
            if(xyStart[i][0] < 0) {
                xyStart[i][0] += 340;
            }
            xyEnd[i][0] = xyStart[i][0] + width[i];
        }
    }

    //draw result screen according to the region
    if(region==1){
        drawResultScreen(region, whichFish, user, pondPrice, fish, pondFish[fish[whichFish]], width[whichFish]);
    }else if(region==2){
        drawResultScreen(region, whichFish, user, riverPrice, fish, riverFish[fish[whichFish]], width[whichFish]);
    }else if(region==3){
        drawResultScreen(region, whichFish, user, seaPrice, fish, seaFish[fish[whichFish]], width[whichFish]);
    }

    //record user stats
    recordStats(user);
}

/*By Evan D and JJ K. this function draw the result screen (call from the play function) which display image 
of fish caught and fish's name, the money the user gained and three button user can click to replay in same region,
go back to select region screen, or back to main menu*/
void drawResultScreen(int region, int whichFish, userStats &user, int price[], int fish[], char* name, int w) {
    //set variables for touch and coordinates
    float x_position, y_position, x_trash, y_trash;
    int yTitle = 45, xDraw = 100, yDraw = 70, xMoney = 110, yMoney =130;
    int xText = xDraw+w+5, yText = yDraw+(w-15)/2;
    int yButton = 170;
    //display a results screen
    LCD.SetFontColor(BLACK);
    //draw background
    FEHImage bg;
    bg.Open("Result-bgFEH.pic");
    bg.Draw(40,40);
    bg.Close();
    //display fish picture and its name and money gained
    if(whichFish!=-1){
        LCD.SetFontColor(BLACK);
        LCD.WriteAt("You Caught: ",95,yTitle);
        //depending on region, print fish name and how much fish worth
        if(region == 1) {
            drawFishPond(name, xDraw, yDraw);
            getPondName(fish[whichFish], xText, yText);
        }
        else if(region == 2) {
            drawFishRiver(name, xDraw, yDraw);
            getRiverName(fish[whichFish], xText, yText);
        }
        else if(region == 3) {
            drawFishSea(name, xDraw, yDraw);
            getSeaName(fish[whichFish], xText, yText);
        }
        //update user's money
        //replace value of 10 with value of fish
        //use users value multiplier to multiply money gained
        user.changeLevel('m',user.getLevel('v')*price[fish[whichFish]]);
        LCD.SetFontColor(GREEN);
        //display money gained
        LCD.WriteAt(user.getLevel('v')*price[fish[whichFish]],xMoney+53,yMoney+5);
        
    }else{
        //display no fish caught
        LCD.SetFontColor(BLACK);
        LCD.WriteAt("No fish Caught!",70,yTitle+45);
        LCD.SetFontColor(RED);
        LCD.WriteAt("0",xMoney+53,yMoney+5);
    }
    //display money icon
    LCD.SetFontColor(BLACK);
    LCD.WriteAt("+", xMoney + 40, yMoney+5);
    drawMoney(xMoney,yMoney);
    //draw the button
    drawBack(110, yButton);
    drawReplay(150, yButton);
    drawHome(190, yButton);
    
    //sleep for 2 seconds so that the results screen is not skipped
    Sleep(2.0);
    //clear touch buffer
    LCD.ClearBuffer();
    //this creates a click to continue once the bobber movement loop has been completed.
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}

    //check which button user touched
    if((x_position >= 190 && x_position <= 210) && (y_position >= yButton && y_position <= yButton+20)) {
        //return to main menu
        Menu(user);
    }
    else if((x_position >= 110 && x_position <= 130) && (y_position >= yButton && y_position <= yButton+20)){
        //select new region
        selectRegion(&region, user);
    }
    else if((x_position >= 150 && x_position <= 170) && (y_position >= yButton && y_position <= yButton+20)) {
        //replay in the same region
        Play(user, region);
    }
    else {
        //stay in this screen
        drawResultScreen(region, whichFish, user, price, fish, name, w);
    }
}

/*by JJ K. this function check for collision by using the coordinate of two object and their width*/
bool collision(int x11, int x12, int y11, int y12, int x21, int x22, int y21, int y22, int r){
    //get center coordinate
    int xCenter1 = (x11+x12)/2;
    int yCenter1 = (y11+y12)/2;
    int xCenter2 = (x21 + x22)/2;
    int yCenter2 = (y21 + y22)/2;
    //if the differences in x and y center coordinate is less that the width then they overlap
    return abs(xCenter1 - xCenter2) < r && abs(yCenter1 - yCenter2) < r;
}

/*by JJ K. this function ask user which region they want to catch the fish*/
void selectRegion(int* region, userStats &user) {
    //declare variables for touch
    float x_position, y_position, x_trash, y_trash;
    //user main menu background
    drawBackground(0);

    //print title and options
    LCD.SetFontColor(BLACK);
    LCD.WriteAt("Select", 15, 31);
    LCD.WriteAt("Select", 16, 32);
    LCD.WriteAt("Region", 60, 56);
    LCD.WriteAt("Region", 61, 57);
    LCD.WriteAt("Pond", 41, 121);
    LCD.WriteAt("River", 37, 151);
    LCD.WriteAt("Sea", 45, 181);
    drawHome(280, 200);

    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}

    //check where user touched screen
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        //return to main menu
        Menu(user);
    }
    else if((x_position >= 41 && x_position <= 88) && (y_position >= 121 && y_position <=136)){
        //call play with region
        *region = 1;
        Play(user, *region);
    }
    else if((x_position >= 37 && x_position <= 98) && (y_position >= 151 && y_position <=166)) {
        //call play with region
        *region = 2;
        Play(user, *region);
    }
    else if((x_position >= 45 && x_position <= 82) && (y_position >= 181 && y_position <=196)) {
        //call play with region
        *region = 3;
        Play(user, *region);
    }
    else {
        //stay in screen
        selectRegion(region, user);
    }
}

/*by Evan D. this function displays upgrades to the user as well as checks to see if they want
to upgrade something and if they can. depending on the users balance as well as their click location, 
a game modifier will be changed.*/
void Stats(userStats &user, int fish) {
    //declare variables for touch
    float x_position, y_position, x_trash, y_trash;
    ///draw background
    drawBackground(4);
    //display all the stats and upgrades
    LCD.SetFontColor(BLACK);
    LCD.WriteAt("Statistics", 90, 8);
    LCD.WriteAt("Statistics", 91, 9);
    LCD.WriteAt("Money: $", 40, 70);
    LCD.SetFontColor(YELLOWGREEN);
    LCD.WriteAt(user.getMoney(), 150, 70);
    LCD.SetFontColor(BLACK);
    LCD.WriteAt("Fish caught: ", 40, 90);
    LCD.WriteAt(user.getFishCaught(), 190, 90);
    LCD.WriteAt("Descent Level: ", 40, 110);
    LCD.WriteAt(user.getDescentLevel(), 210, 110);
    LCD.WriteAt(5000*user.getLevel('d'), 240, 110);
    LCD.WriteAt("Speed Level: ", 40, 130);
    LCD.WriteAt(user.getHorizontalLevel(), 190, 130);
    LCD.WriteAt(5000*user.getLevel('h'), 240, 130);
    LCD.WriteAt("Value x: ", 40, 150);
    LCD.WriteAt(user.getValue(), 150, 150);
    LCD.WriteAt(50000*user.getLevel('v'), 240, 150);
    drawHome(280, 200);

    //draw a shop icon
    FEHImage shop;
    shop.Open("shopFEH.pic");
    shop.Draw(250, 70);
    shop.Close();

    Sleep(.5);
    //clear touch buffer
    LCD.ClearBuffer();
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    //depending on location of users touch, perform an action
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        recordStats(user);
        //return to main menu
        Menu(user);
    }
    else if((x_position >= 240 && x_position <= 320) && (y_position >= 110 && y_position <= 125)&&(user.getLevel('m')>=5000*user.getLevel('d'))&&(user.getLevel('d')<5)){
        //this statement upgrades descent speed if have enough money and less than max level.
        //remove money from users balance and then upgrade
        user.changeLevel('m',-5000*user.getLevel('d'));
        user.changeLevel('d',1);
        recordStats(user);
        Stats(user, fish);
    }
    else if((x_position >= 240 && x_position <= 320) && (y_position >= 130 && y_position <= 145)&&(user.getLevel('m')>=5000*user.getLevel('h'))){
        //this statement upgrades horizontal speed if have enough money
        //remove money from users balance and then upgrade
        user.changeLevel('m',-5000*user.getLevel('h'));
        user.changeLevel('h',1);
        recordStats(user);
        Stats(user, fish);
    }
    else if((x_position >= 240 && x_position <= 320) && (y_position >= 150 && y_position <= 165)&&(user.getLevel('m')>=50000*user.getLevel('v'))){
        //this statement upgrades value multiplier if have enough money
        //remove money from users balance and then upgrade
        user.changeLevel('m',-50000*user.getLevel('v'));
        user.changeLevel('v',1);
        recordStats(user);
        Stats(user, fish);
    }
    else {
        //stay in stats
        Stats(user, fish);
    }
}

/*by Evan D. this function call another function to write the rule of the game depending on the page number*/
void Rule(int page, userStats &user) {
    //declare variable for touch
    float x_position, y_position, x_trash, y_trash;
    int nextXPos=225,previousXPos=40;

    //draw backgroun
    drawBackground(4);

    LCD.SetFontColor(BLACK);
    //display title and main menu button
    LCD.WriteAt("How to Play", 90, 5);
    LCD.WriteAt("How to Play", 91, 6);
    drawHome(280, 200);
    
    //draw back and nexr arrow
    if(page < 3) {
        drawArrow(2, nextXPos, 190);
    }
    if(page > 1){
        drawArrow(1, previousXPos, 190);
    }
    //display current page of instructions
    LCD.SetFontColor(BLACK);
    drawInstruction(page);
    Sleep(.5);
    //clear touch buffer
    LCD.ClearBuffer();
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    //check where user touch the screen
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        //return to main menu
        Menu(user);
    }else if((x_position>=nextXPos && x_position<=nextXPos+29)&&(y_position>=190 && y_position<=217)&&(page<3)){
        //increment page number IF click within region and if maximum page is not reached
        page++;
        Rule(page,user);
    }else if((x_position>=previousXPos && x_position<=previousXPos+29)&&(y_position>=190 && y_position<=217)&&(page>1)){
        //decrement page number IF click within region and if minimum page is not reached
        page--;
        Rule(page,user);
    }else {
        //stay on the screen
        Rule(page,user);
    }
}

/*by JJ K. this function draw the collection of fish according to its region and page number, include back butto to select collection screen*/
void collection(int region, int page, userStats &user) {
    //declare variable for touch
    float x_position, y_position, x_trash, y_trash;
    int nextXPos=276,previousXPos=15, pageMax = 1;

    //draw background and set pageMax according to region
    drawBackground(region);
    if(region == 1) {
        pageMax = 2;
    }
    else if(region == 2) {
        pageMax = 4;
    }
    else if(region == 3) {
        pageMax = 5;
    }
    //draw back button
    drawBack(280, 200);

    //draw arrows
    if(page < pageMax) {
        drawArrow(2, nextXPos, 5);
    }
    if(page > 1){
        drawArrow(1, previousXPos, 5);
    }
    
    //draw collection according to region and page number
    LCD.SetFontColor(BLACK);
    if(region == 1) {
        pondCollection(page);
    }
    else if(region == 2) {
        riverCollection(page);
    }
    else if(region == 3) {
        seaCollection(page);
    }

    Sleep(.1);
    //clear touch buffer
    LCD.ClearBuffer();
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}

    //check where user touched
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        //return to main menu
        selectCollection(&region, user);
    }else if((x_position>=nextXPos && x_position<=nextXPos+29)&&(y_position>=5 && y_position<=32)&&(page<pageMax)){
        //increment page number IF click within region and if maximum page is not reached
        page++;
        collection(region, page, user);
    }else if((x_position>=previousXPos && x_position<=previousXPos+29)&&(y_position>=5 && y_position<=32)&&(page>1)){
        //decrement page number IF click within region and if minimum page is not reached
        page--;
        collection(region, page, user);
    }else {
        //stay on screen
        collection(region, page, user);
    }
}

/*by JJ K. this function ask user to select collection they want to view and call the collection function*/
void selectCollection(int* region, userStats &user) {
    //declare variables for touch
    float x_position, y_position, x_trash, y_trash;
    //user main menu background
    drawBackground(0);

    //print title and options
    LCD.SetFontColor(BLACK);
    LCD.WriteAt("Select", 15, 31);
    LCD.WriteAt("Select", 16, 32);
    LCD.WriteAt("Collection", 30, 56);
    LCD.WriteAt("Collection", 31, 57);
    LCD.WriteAt("Pond", 41, 121);
    LCD.WriteAt("River", 37, 151);
    LCD.WriteAt("Sea", 45, 181);
    drawHome(280, 200);

    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}

    //check where user touched screen
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        //return to main menu
        Menu(user);
    }
    else if((x_position >= 41 && x_position <= 88) && (y_position >= 121 && y_position <=136)){
        //call play with region
        *region = 1;
        collection(*region, 1, user);
    }
    else if((x_position >= 37 && x_position <= 98) && (y_position >= 151 && y_position <=166)) {
        //call play with region
        *region = 2;
        collection(*region, 1, user);
    }
    else if((x_position >= 45 && x_position <= 82) && (y_position >= 181 && y_position <=196)) {
        //call play with region
        *region = 3;
        collection(*region, 1, user);
    }
    else {
        //stay in screen
        selectCollection(region, user);
    }
}

/*by JJ K. this function draw pond fish collection based on page number with images of each fish and its name*/
void pondCollection(int page) {
    //write title
    LCD.WriteAt("POND", 140, 10);
    LCD.WriteAt("POND", 141, 11);
    //declare variables
    char pondFish[12][50] = {"M_Carp_FEH.pic", "M_Catfish_FEH.pic", "S_Crawfish_FEH.pic", "S_Frog_FEH.pic", "L_Gar_FEH.pic", "M_Giant_Snakehead_FEH.pic", "S_Goldfish_FEH.pic", "S_Killifish_FEH.pic", "M_Koi_FEH.pic", "S_Tadpole_FEH.pic", "S_Pop-Eyed_Goldfish_FEH.pic", "S_Ranchu_Goldfish_FEH.pic"};
    int width[12];
    //get width of fish
    getWidth(pondFish, width, 12);
    //declare counter
    int num = 0, xStart = 15, yStart = 110, xNext = 150, yNext = 40, region = 1;
    int x = xStart, y = yStart, w, buffer = 3, xText, yText;
    //display each page differently, each page contains 6 fish
    switch(page) {
        case 1:
            num = 0;
            //loop to draw fishh
            for(int i = 0; i < 3; i++) {
                //reset x coordinate
                x = xStart;
                w = width[num] + buffer;
                for(int j = 0; j < 2; j++) {
                    //get width of fish
                    if(width[num] > w) {
                        w = width[num] + buffer;
                    }
                    //draw fish icon
                    drawFishPond(pondFish[num], x, y);
                    //draw rectangle over if fish was caught
                    if(checkFishCaught(region, num)) {
                        LCD.SetFontColor(GREENYELLOW);
                        LCD.DrawRectangle(x, y, width[num], width[num]);
                    }
                    //text coordinates
                    xText = x+width[num] + buffer;
                    yText = y + width[num]/4;
                    ///draw name of fish
                    getPondName(num, xText, yText);
                    x += xNext;
                    //increment num
                    num++;
                }
                //increment y
                y += w;
            }
            break;
        case 2:
            num = 6;
            //loop to draw each fish
            for(int i = 0; i < 3; i++) {
                //reset x coordinate
                x = xStart;
                w = width[num] + buffer;
                for(int j = 0; j < 2; j++) {
                    //get width
                    if(width[num] > w) {
                        w = width[num] + buffer;
                    }
                    //format this fish specifically
                    if(num == 9) {
                        y += 5;
                    }
                    //draw fish icon
                    drawFishPond(pondFish[num], x, y);
                    //draw rectangle over if fish was caught
                    if(checkFishCaught(region, num)) {
                        LCD.SetFontColor(GREENYELLOW);
                        LCD.DrawRectangle(x, y, width[num], width[num]);
                    }
                    //initialize text coordinate
                    xText = x+width[num] + buffer;
                    yText = y + width[num]/4;
                    //draw fish name
                    getPondName(num, xText, yText);
                    x += xNext;
                    //increment num
                    num++;
                }
                //reset y specific increment
                if(num == 9) {
                    y -= 5;
                }
                //increment y
                y += w;
            }
            break;
        default:
            break;
    }
}

/*by JJ K. this function draw river fish collection based on page number with images of each fish and its name*/
void riverCollection(int page) {
    //display title
    LCD.WriteAt("RIVER", 130, 10);
    LCD.WriteAt("RIVER", 131, 11);
    //initialize variables
    char riverFish[15][50] = {"S_Angelfish_FEH.pic", "L_Arapaima_FEH.pic", "M_Arowana_FEH.pic", "S_Betta_FEH.pic", "L_Dorado_FEH.pic", "S_Freshwater_Goby_FEH.pic", "M_Golden_Trout_FEH.pic", "S_Neon_FEH.pic", "S_Pale_Chub_FEH.pic", "S_Piranha_FEH.pic", "M_Saddled_FEH.pic", "M_Salmon_FEH.pic", "M_Snapping_Turtle_FEH.pic", "L_Sturgeon_FEH.pic", "M_Tilapia_FEH.pic"};
    int width[15];
    //initialize width of fish
    getWidth(riverFish, width, 15);
    ////declare coordinate and counter variable
    int num = 0, xStart = 15, yStart = 115, xNext = 150, yNext = 10, xMiddle = 70, region = 2;
    int x = xStart, y = yStart, w, buffer = 5, buffer2 = 15, xText, yText;
    //display different fish depending on page
    switch(page) {
        case 1:
            num = 0, yNext = 10;
            for(int i = 0; i < 2; i++) {
                x = xStart;
                w = width[num] + buffer;
                for(int j = 0; j < 2; j++) {
                    if(width[num] > w) {
                        w = width[num] + buffer;
                    }
                    if(num == 0) {
                        y += buffer*2;
                    }
                    if(num == 1) {
                        y -= buffer;
                    }
                    if(num == 3) {
                        y += buffer;
                    }
                    //draw fish icon
                    drawFishRiver(riverFish[num], x, y);
                    //draw rectangle over if fish was caught
                    if(checkFishCaught(region, num)) {
                        LCD.SetFontColor(YELLOW);
                        LCD.DrawRectangle(x, y, width[num], width[num]);
                    }
                    //initialize text coordinate
                    xText = x+width[num] + buffer;
                    yText = y + width[num]/4;
                    //display fish's name
                    getRiverName(num, xText, yText);
                    x += xNext;
                    num++;
                }
                y += w;
            }
            break;
        case 2:
            num = 4, yNext = 20;
            for(int i = 0; i < 2; i++) {
                x = xStart;
                w = width[num] + buffer;
                for(int j = 0; j < 2; j++) {
                    if(width[num] > w) {
                        w = width[num] + buffer;
                    }
                    if(num ==7){
                        y +=buffer*2;
                    }
                    if(num == 5){
                        y +=buffer*2;
                    }
                    //draw fish icon
                    drawFishRiver(riverFish[num], x, y);
                    //draw rectangle over if fish was caught
                    if(checkFishCaught(region, num)) {
                        LCD.SetFontColor(YELLOW);
                        LCD.DrawRectangle(x, y, width[num], width[num]);
                    }
                    //initialize text coordinate
                    xText = x+width[num] + buffer;
                    yText = y + width[num]/4;
                    //display fish's name
                    getRiverName(num, xText, yText);
                    x += xNext;
                    num++;
                    
                }
                if(num ==7){
                    y -=buffer*2;
                }
                if(num == 5){
                    y -=buffer*2;
                }
                y += w;
            }
            break;
        case 3:
            num = 8, yNext = 30, y = 125;
            for(int i = 0; i < 2; i++) {
                x = xStart;
                w = width[num] + yNext;
                for(int j = 0; j < 2; j++) {
                    if(width[num] > w) {
                        w = width[num] + buffer;
                    }
                    //draw fish icon
                    drawFishRiver(riverFish[num], x, y);
                    //draw rectangle over if fish was caught
                    if(checkFishCaught(region, num)) {
                        LCD.SetFontColor(YELLOW);
                        LCD.DrawRectangle(x, y, width[num], width[num]);
                    }
                    //initialize text coordinate
                    xText = x+width[num] + buffer;
                    yText = y + width[num]/4;
                    //display fish's name
                    getRiverName(num, xText, yText);
                    x += xNext;
                    num++;
                }
                y += w;
            }
            break;
        case 4:
            num = 12, yNext = 20, y = 125, xMiddle = 100;
            for(int i = 0; i < 2; i++) {
                x = xStart;
                w = width[num] + yNext;
                for(int j = 0; j < 2; j++) {
                    if(i < 1) {
                        //draw fish icon
                        drawFishRiver(riverFish[num], x, y);
                        //draw rectangle over if fish was caught
                        if(checkFishCaught(region, num)) {
                            LCD.SetFontColor(YELLOW);
                            LCD.DrawRectangle(x, y, width[num], width[num]);
                        }
                        //initialize text coordinate
                        xText = x+width[num] + buffer;
                        yText = y + width[num]/4;
                        //display fish's name
                        getRiverName(num, xText, yText);
                    }
                    else {
                        //draw fish icon using middle coordinate
                        drawFishRiver(riverFish[num], xMiddle, y);
                        //draw rectangle over if fish was caught
                        if(checkFishCaught(region, num)) {
                            LCD.SetFontColor(YELLOW);
                            LCD.DrawRectangle(xMiddle, y, width[num], width[num]);
                        }
                        //initialize text coordinate
                        xText = xMiddle+width[num] + buffer;
                        yText = y + width[num]/4;
                        //display fish's name
                        getRiverName(num, xText, yText + buffer);
                        num++;
                        break;
                    }
                    x += xNext;
                    num++;
                }
                y += w;
            }
            break;
        default:
            break;
    }
}

/*by JJ K. this function draw sea fish collection based on page number with images of each fish and its name*/
void seaCollection(int page) {
    //write title
    LCD.WriteAt("SEA", 145, 10);
    LCD.WriteAt("SEA", 146, 11);
    //initialize variables
    char seaFish[15][50] = {"M_Blowfish_FEH.pic", "S_Butterfly_Fish_FEH.pic", "S_Clown_Fish_FEH.pic", "L_Coelacanth_FEH.pic", "M_Dab_FEH.pic", "L_Great_White_Shark_FEH.pic", "L_Napoleonfish_FEH.pic", "L_Ocean_Sunfish_FEH.pic", "M_Red_Snapper_FEH.pic", "L_Saw_Shark_FEH.pic", "S_Sea_Horse_FEH.pic", "M_Squid_FEH.pic", "L_Suckerfish_FEH.pic", "S_Surgeonfish_FEH.pic", "L_Whale_Shark_FEH.pic"};
    int width[15];
    //get width of fish
    getWidth(seaFish, width, 15);
    //initialize coordinate and counter variables
    int num = 0, xStart = 15, yStart = 115, xNext = 150, yNext = 10, xMiddle = 80, region = 3;
    int x = xStart, y = yStart, w, buffer = 5, buffer2 = 15, xText, yText;
    switch(page) {
        case 1:
            yNext = 30;
            num = 0;
            for(int i = 0; i < 2; i++) {
                w = width[num] + yNext;
                //draw fish icon
                drawFishSea(seaFish[num], x, y);
                //draw rectangle over if fish was caught
                if(checkFishCaught(region, num)) {
                    LCD.SetFontColor(BLUE);
                    LCD.DrawRectangle(x, y, width[num], width[num]);
                }
                //initialize text coordinate
                xText = x+width[num] + buffer;
                yText = y + width[num]/4;
                //display fish's name
                getSeaName(num, xText, yText);
                x += xNext;
                num++;
                y += buffer;
            }
            y += w;
            //draw fish icon
            drawFishSea(seaFish[num], xMiddle, y);
            //draw rectangle over if fish was caught
            if(checkFishCaught(region, num)) {
                LCD.SetFontColor(BLUE);
                LCD.DrawRectangle(xMiddle, y, width[num], width[num]);
            }
            //initialize text coordinate
            xText = xMiddle+width[num] + buffer;
            yText = y + width[num]/4;
            //display fish's name
            getSeaName(num, xText, yText);
            num++;
            break;
        case 2:
            num = 3;
            yStart = 110, xNext = 190, yNext = 5;
            for(int i = 0; i < 2; i++) {
                w = width[num] + yNext;
                //draw fish icon
                drawFishSea(seaFish[num], x, y);
                //draw rectangle over if fish was caught
                if(checkFishCaught(region, num)) {
                    LCD.SetFontColor(BLUE);
                    LCD.DrawRectangle(x, y, width[num], width[num]);
                }
                //initialize text coordinate
                xText = x+width[num] + buffer;
                yText = y + width[num]/4;
                //display fish's name
                getSeaName(num, xText, yText);
                    
                x += xNext;
                num++;
                y+=buffer;
            }
            y += w;
            //draw fish icon
            drawFishSea(seaFish[num], xMiddle, y);
            //draw rectangle over if fish was caught
            if(checkFishCaught(region, num)) {
                LCD.SetFontColor(BLUE);
                LCD.DrawRectangle(xMiddle, y, width[num], width[num]);
            }
            //initialize text coordinate
            xText = xMiddle+width[num] + buffer;
            yText = y + width[num]/4;
            //display fish's name
            getSeaName(num, xText, yText);
            num++;
            break;
        case 3:
            num = 6;
            yNext = 20;
            for(int i = 0; i < 2; i++) {
                w = width[num] + yNext;
                //draw fish icon
                drawFishSea(seaFish[num], x, y);
                //draw rectangle over if fish was caught
                if(checkFishCaught(region, num)) {
                    LCD.SetFontColor(BLUE);
                    LCD.DrawRectangle(x, y, width[num], width[num]);
                }
                //initialize text coordinate
                xText = x+width[num] + buffer;
                yText = y + width[num]/4;
                //display fish's name
                getSeaName(num, xText, yText);
                x += xNext;
                num++;
                
            }
            y += w;
            //draw fish icon
            drawFishSea(seaFish[num], xMiddle, y);
            //draw rectangle over if fish was caught
            if(checkFishCaught(region, num)) {
                LCD.SetFontColor(BLUE);
                LCD.DrawRectangle(xMiddle, y, width[num], width[num]);
            }
            //initialize text coordinate
            xText = xMiddle+width[num] + buffer;
            yText = y + width[num]/4;
            //display fish's name
            getSeaName(num, xText, yText);
            break;
        case 4:
            num = 9, xStart = 10, xNext =160, buffer =2;
            xMiddle = 110;
            for(int i = 0; i < 2; i++) {
                w = width[num] + yNext;
                //draw fish icon
                drawFishSea(seaFish[num], x, y);
                //draw rectangle over if fish was caught
                if(checkFishCaught(region, num)) {
                    LCD.SetFontColor(BLUE);
                    LCD.DrawRectangle(x, y, width[num], width[num]);
                }
                //initialize text coordinate
                xText = x+width[num] + buffer;
                yText = y + width[num]/4;
                //display fish's name
                getSeaName(num, xText, yText);
                x += xNext;
                num++;
                y += buffer*2;
            }
            y += w + buffer2;
            //draw fish icon
            drawFishSea(seaFish[num], xMiddle, y);
            //draw rectangle over if fish was caught
            if(checkFishCaught(region, num)) {
                LCD.SetFontColor(BLUE);
                LCD.DrawRectangle(xMiddle, y, width[num], width[num]);
            }
            //initialize text coordinate
            xText = xMiddle+width[num] + buffer;
            yText = y + width[num]/4;
            //display fish's name
            getSeaName(num, xText, yText);

            break;   
        case 5:
            num = 12;
            yNext = 10;
            for(int i = 0; i < 2; i++) {
                w = width[num] + yNext;
                //draw fish icon
                drawFishSea(seaFish[num], x, y);
                //draw rectangle over if fish was caught
                if(checkFishCaught(region, num)) {
                    LCD.SetFontColor(BLUE);
                    LCD.DrawRectangle(x, y, width[num], width[num]);
                }
                //initialize text coordinate
                xText = x+width[num] + buffer;
                yText = y + width[num]/4;
                //display fish's name
                getSeaName(num, xText, yText);
                x += xNext;
                num++;
                y += buffer;
            }
            y += w + buffer*2;
            //draw fish icon
            drawFishSea(seaFish[num], xMiddle, y);
            //draw rectangle over if fish was caught
            if(checkFishCaught(region, num)) {
                LCD.SetFontColor(BLUE);
                LCD.DrawRectangle(xMiddle, y, width[num], width[num]);
            }
            //initialize text coordinate
            xText = xMiddle+width[num] + buffer;
            yText = y + width[num]/4;
            //display fish's name
            getSeaName(num, xText, yText + buffer);
            break;           
        default:
            break;
    }
}


/*By Evan D. the next 3 functions (getRegionName) all take an integer index value, and x and y coordinates.
It prints out the name of the fish without any file type at the end corresponding to the input index value.
it then writes the name on the screen at the x and y coordinates.*/
void getPondName(int fishNum, int x, int y){
    int buffer = 20;
    switch(fishNum){
        case 0:
            LCD.WriteAt("Carp",x,y);
            break;
        case 1:
            LCD.WriteAt("Catfish",x,y);
            break;
        case 2:
            LCD.WriteAt("Crawfish",x,y);
            break;
        case 3:
            LCD.WriteAt("Frog",x,y);
            break;
        case 4:
            LCD.WriteAt("Gar",x,y);
            break;
        case 5:
            LCD.WriteAt("Giant",x,y);
            LCD.WriteAt("Snakehead",x-25,y+buffer);
            break;
        case 6:
            LCD.WriteAt("Goldfish",x,y);
            break;
        case 7:
            LCD.WriteAt("Killifish",x,y);
            break;
        case 8:
            LCD.WriteAt("Koi",x,y);
            break;
        case 9:
            LCD.WriteAt("Tadpole",x,y);
            break;
        case 10:
            LCD.WriteAt("Pop-Eyed",x,y);
            LCD.WriteAt("Goldfish",x,y+buffer);
            break;
        case 11:
            LCD.WriteAt("Ranchu",x,y);
            LCD.WriteAt("Goldfish",x-10,y+buffer);
            break;
        
    }
        
    
}
void getRiverName(int fishNum, int x, int y){
    int buffer = 20;
    switch(fishNum){
        case 0:
            LCD.WriteAt("Angelfish",x,y);
            break;
        case 1:
            LCD.WriteAt("Arapaima",x,y);
            break;
        case 2:
            LCD.WriteAt("Arowana",x,y);
            break;
        case 3:
            LCD.WriteAt("Betta",x,y);
            break;
        case 4:
            LCD.WriteAt("Dorado",x,y);
            break;
        case 5:
            LCD.WriteAt("Freshwater",x,y);
            LCD.WriteAt("Goby",x+25,y+buffer);
            break;
        case 6:
            LCD.WriteAt("Golden",x,y);
            LCD.WriteAt("Trout",x-5,y+buffer);
            break;
        case 7:
            LCD.WriteAt("Neon",x,y);
            break;
        case 8:
            LCD.WriteAt("Pale Chub",x,y);
            break;
        case 9:
            LCD.WriteAt("Piranha",x,y);
            break;
        case 10:
            LCD.WriteAt("Saddled",x,y);
            break;
        case 11:
            LCD.WriteAt("Salmon",x,y);
            break;
        case 12:
            LCD.WriteAt("Snapping",x,y);
            LCD.WriteAt("Turtle",x+10,y+buffer);
            break;
        case 13:
            LCD.WriteAt("Sturgeon",x,y);
            break;
        case 14:
            LCD.WriteAt("Tilapia",x,y);
            break;
    }
}
void getSeaName(int fishNum, int x, int y){
    int buffer = 20;
    switch(fishNum){
        case 0:
            LCD.WriteAt("Blowfish",x,y);
            break;
        case 1:
            LCD.WriteAt("Butterfly",x,y);
            LCD.WriteAt("Fish",x+20,y+buffer);
            break;
        case 2:
            LCD.WriteAt("Clown Fish",x,y);
            break;
        case 3:
            LCD.WriteAt("Coelacanth",x,y);
            break;
        case 4:
            LCD.WriteAt("Dab",x,y);
            break;
        case 5:
            LCD.WriteAt("Great",x,y);
            LCD.WriteAt("White Shark",x-15,y+buffer+3);
            break;
        case 6:
            LCD.WriteAt("Napoleon",x,y);
            LCD.WriteAt("Fish",x+15,y+buffer);
            break;
        case 7:
            LCD.WriteAt("Ocean",x,y);
            LCD.WriteAt("Sunfish",x-10,y+buffer);
            break;
        case 8:
            LCD.WriteAt("Red Snapper",x,y);
            break;
        case 9:
            LCD.WriteAt("Saw Shark",x,y);
            break;
        case 10:
            LCD.WriteAt("Sea Horse",x,y);
            break;
        case 11:
            LCD.WriteAt("Squid",x,y);
            break;
        case 12:
            LCD.WriteAt("Sucker",x,y);
            LCD.WriteAt("Fish",x+10,y+buffer);
            break;
        case 13:
            LCD.WriteAt("Surgeon",x,y);
            LCD.WriteAt("Fish",x+15,y+buffer);
            break;
        case 14:
            LCD.WriteAt("Whale Shark",x,y);
            break;
    }
}

/*by JJ K. this function get the width of the fish based on their size*/
void getWidth(char name[][50], int* width, int size) {
    for(int i = 0; i < size; i++) {
        //get the size of the fish
        if(name[i][0] == 'S') {
            width[i] = 20;
        }
        else if(name[i][0] == 'M') {
            width[i] = 30;
        }
        else if(name[i][0] == 'L') {
            width[i] = 45;
        }
    }
}

/*by JJ K. this function display credit screen*/
void Credits(userStats &user) {
    //declare variables for touch
    float x_position, y_position, x_trash, y_trash;
    drawBackground(4);
    //display developer names
    LCD.SetFontColor(BLACK);
    LCD.WriteAt("Developers", 94, 11);
    LCD.WriteAt("Evan Davis", 94, 91);
    LCD.WriteAt("JJ Kiratikosolrak", 60, 121);
    drawHome(280, 200);
    Sleep(.5);
    //clear touch buffer
    LCD.ClearBuffer();
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    //return to main menu
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        Menu(user);
    }
    else {
        Credits(user);
    }
}

/*by JJ K. this function draw home icon*/
void drawHome(int x, int y) {
    FEHImage home;
    home.Open("homeFEH.pic");
    home.Draw(x, y);
    home.Close();
}
/*by JJ K. this function draw setting icon*/
void drawSetting(int x, int y) {
    FEHImage icon;
    icon.Open("settingFEH.pic");
    icon.Draw(x, y);
    icon.Close();
}
/*by JJ K. this function draw reset icon*/
void drawReset(int x, int y) {
    FEHImage icon;
    icon.Open("resetFEH.pic");
    icon.Draw(x, y);
    icon.Close();
}
/*by JJ K. this function draw replay icon*/
void drawReplay(int x, int y) {
    FEHImage icon;
    icon.Open("replayFEH.pic");
    icon.Draw(x, y);
    icon.Close();
}
/*by JJ K. this function draw back icon*/
void drawBack(int x, int y) {
    FEHImage icon;
    icon.Open("backFEH.pic");
    icon.Draw(x, y);
    icon.Close();
}
/*by JJ K. this function draw money icon*/
void drawMoney(int x, int y) {
    FEHImage icon;
    icon.Open("moneyFEH.pic");
    icon.Draw(x, y);
    icon.Close();
}

/*by JJ K. this function display the setting screen with options to reset all stats and delete current fish collection
user has to press on reset button for the resetting to work (prevent accidental touch)*/
void setSettingScreen(userStats &user) {
    //declare variables for touch
    float x_position, y_position, x_trash, y_trash;
    //draw background
    drawBackground(4);
    //display options and reset buttons
    LCD.SetFontColor(BLACK);
    LCD.WriteAt("Setting", 115, 11);
    LCD.WriteAt("Setting", 116, 12);
    LCD.WriteAt("Delete Fish Collection", 40, 91);
    drawReset(15, 89);
    LCD.SetFontColor(BLACK);
    LCD.WriteAt("Reset Statistics", 70, 131);
    drawReset(45, 129);
    drawHome(280, 200);
    Sleep(.5);
    //clear touch buffer
    LCD.ClearBuffer();
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    //check where user touched the screen
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        //return to main menu
        Menu(user);
    }
    else if((x_position >= 15 && x_position <= 35) && (y_position >= 89 && y_position <=109)) {
        //empty the fishCaught file
        ofstream output;
        output.open("fishCaught.txt");
        output.close();
    }
    else if((x_position >= 45 && x_position <= 65) && (y_position >= 129 && y_position <=149)) {
        //reset the stats to initial value
        user.resetStats();
    }
    else {
        //screen remain unchanged
        setSettingScreen(user);
    }
}

/*by Evan D. this function draws the instructions on the page and looks for user input to navigate to
another page or back to the main menu*/
void drawInstruction(int page){
    //print the instructions for the corresponding page. starts at y=30 and goes to y=165
    //i love no auto wraparound text!
    //15 pixel line spacing
    switch(page){
        case 1:
            LCD.WriteAt("Touch left or right of",25,50);
            LCD.WriteAt("bobber to move bobber.",30,70);
            LCD.WriteAt("Guide the bobber to catch",10,95);
            LCD.WriteAt("a fish in the water.",40,115);
            LCD.WriteAt("Each fish is worth",45,140);
            LCD.WriteAt("different amount of money.",10,160);
            // LCD.WriteAt("To play, touch play on",10,30);
            // LCD.WriteAt("the main menu. Your goal",10,45);
            // LCD.WriteAt("is to guide the bobber to",10,60);
            // LCD.WriteAt("a fish before the time",10,75);
            // LCD.WriteAt("runs out or the bobber",10,90);
            // LCD.WriteAt("reaches the bottom. You",10,105);
            // LCD.WriteAt("will receive more money",10,120);
            // LCD.WriteAt("depending on how much",10,135);
            // LCD.WriteAt("the fish is worth. More",10,150);
            // LCD.WriteAt("valuable fish are below.",10,165);
            LCD.WriteAt("1",145,195);
            break;
        case 2:
            LCD.WriteAt("Spend money on upgrading",10,55);
            LCD.WriteAt("speed of the bobber",35,75);
            LCD.WriteAt("and value of fish.",45,95);
            LCD.WriteAt("Collect all fish",50,130);
            LCD.WriteAt("available in each region.",10,150);
            // LCD.WriteAt("You will accumulate money",10,30);
            // LCD.WriteAt("over time, which can be",10,45);
            // LCD.WriteAt("spent on various upgrades.",10,60);
            // LCD.WriteAt("Upgrades increase the",10,75);
            // LCD.WriteAt("speed of descent, the",10,90);
            // LCD.WriteAt("horizontal speed, the",10,105);
            // LCD.WriteAt("value of fish, and the",10,120);
            // LCD.WriteAt("area you are in. Upgrades",10,135);
            // LCD.WriteAt("get more expensive as",10,150);
            // LCD.WriteAt("they are purchased.",10,165);
            LCD.WriteAt("2",145,195);
            break;
        case 3:
            LCD.WriteAt("Stats and collection",30,90);
            LCD.WriteAt("can be deleted in",50,110);
            LCD.WriteAt("setting menu.",80,130);
            LCD.WriteAt("3",145,195);
            break;
    }
}

/*by Evan D. This function takes an integer input for a corresponding background image
0 is main menu background, 1 is pond background, 2 is river background, 3 is sea/beach background
4 is basic background*/
void drawBackground(int BGnum){
    FEHImage BG;
    switch(BGnum){
        case 0:
            BG.Open("mainFEH.pic");
            break;
        case 1:
            BG.Open("Pond-bgFEH.pic");
            break;
        case 2:
            BG.Open("River-bgFEH.pic");
            break;
        case 3:
            BG.Open("Beach-bgFEH.pic");
            break;
        case 4:
            BG.Open("bgFEH.pic");
            break;
    }
    BG.Draw(0,0);
    BG.Close();
}

/* by Evan D and JJ K. Each drawFishRegion function takes 3 integer inputs, 1 for the fish image to draw 
and the other two are the coordinates to draw at.*/
void drawFishPond(char* pond,int x,int y){
    FEHImage Fish;
    Fish.Open(pond);
    Fish.Draw(x,y);
    Fish.Close();
}
void drawFishRiver(char* river, int x,int y){
    FEHImage Fish;
    Fish.Open(river);
    Fish.Draw(x,y);
    Fish.Close();
}
void drawFishSea(char* sea,int x,int y){
    FEHImage Fish;
    Fish.Open(sea);
    Fish.Draw(x,y);
    Fish.Close();
}

/*by JJ K. this function draw the left and right arrow, direction depends on the parameter d (1 or 2)*/
void drawArrow(int d, int x, int y) {
    //29 x 27
    FEHImage arrow;
    //left arrow
    if(d == 1){
        arrow.Open("arrow-leftFEH.pic");
    }
    //right arrow
    else if(d==2) {
        arrow.Open("arrow-rightFEH.pic");
    }
    arrow.Draw(x, y);
    arrow.Close();
}

/*by JJ K. this function return whether or not the fish has been caught using the region and fish number*/
bool checkFishCaught(int region, int fishNum) {
    //declare variables
    int r, num;
    bool caught = false;
    //open fishCaught file for reading
    ifstream fin;
    fin.open("fishCaught.txt");
    //make sure file is open before reading it
    if(fin.is_open()) {
        //exit when at the end of the file or found that the fish wa caught
        while(fin.peek()!=EOF && !caught) {
            fin >> r >> num;
            //if region number and fish number matched, then the fish was caught
            if(r == region && num == fishNum) {
                caught = true;
            }
        }
    }
    fin.close();
    return caught;
}

/*by JJ K. this function record the fish caught by writing the region and fish number*/
void recordFishCaught(int region, int fishNum) {
    //open output file for appending
    ofstream output;
    output.open("fishCaught.txt", ofstream::app);
    //write region and fishnum to file
    if(output.is_open()) {
        output << region << "\t" << fishNum << endl;
    }
    output.close();
}

/*by JJ K. this record the user stats to text file to save stats*/
void recordStats(userStats &user) {
    //open output file to overwrite
    ofstream output;
    output.open("stats.txt");
    if(output.is_open()) {
        //write all stats info in order
        output << user.getMoney() << "\t" << user.getFishCaught() << "\t" << user.getDescentLevel() << "\t" << user.getHorizontalLevel() << "\t" << user.getValue();
    }
    output.close();
}

/*by Evan D. and JJ K. the main function read in old stats data and call main menu with userStats object*/
int main() {

    //read in the recorded stats from previous play
    ifstream fin;
    int m, f, d, h, v;
    fin.open("stats.txt");
    if(fin.is_open()) {
        fin >> m >> f >> d >> h >> v;
    }
    fin.close();

    //create user object using stats recorded
    userStats user1(m, f, d, h, v);
    userStats *user = &user1;

    //Clear background
    LCD.SetBackgroundColor(BLACK);
    LCD.Clear();

    //call menu function
    Menu(*user);

    return 0;
}

