#include "FEHLCD.h"
#include "FEHUtility.h"
#include "FEHRandom.h"
#include "FEHImages.h"
#include <string>
#include <vector>


void Menu();
void Play(float m);
void selectRegion(int* r);
void Stats(float m, int f, int d, int h, int v, int r);
void Rule(int page);
void Credits();
void ClearScreen();
void drawInstruction(int page);
void drawBackground(int BGnum);
void drawFishPond(int fishNum,int x,int y);
void drawFishRiver(int fishNum,int x,int y);
void drawFishSea(int fishNum,int x,int y);
void collection(int page);
void pondCollection();
void riverCollection();
void seaCollection();
void drawHome(int x, int y);
/*
    SDP 4
    Making a main menu​
*/
void Menu() {
    //set variables
    float x_position, y_position, x_trash, y_trash;
    float money = 0;
    int fish = 0, descentLevel = 1, horizontalLevel = 1, valueLevel = 1, region = 1;
    FEHImage play;
    
    while(1) {
        //clear screen
        //ClearScreen();
        drawBackground(0);
        // FEHImage tilapia;
        // tilapia.Open("TilapiaFEH.pic");
        // tilapia.Draw(0,0);
        // tilapia.Close();
        LCD.SetFontColor(BLACK);
        //display main menu middle top screen
        LCD.WriteAt("Fishing", 15, 31);
        LCD.WriteAt("SIM", 90, 61);
        //LCD.WriteAt("Play Game", 10, 111);
        play.Open("Play-ButtonFEH.pic");
        play.Draw(35, 101);
        play.Close();
        LCD.WriteAt("Statistics", 5, 131);
        LCD.WriteAt("Instruction", 2, 151);
        LCD.WriteAt("Collection",5,171);
        LCD.WriteAt("Credits", 25, 191);

        

        Sleep(.5);
        //clear touch buffer
        LCD.ClearBuffer();
        //wait till user touches the screen
        while(!LCD.Touch(&x_position, &y_position)) {}
        //wait until the touch releases
        while(LCD.Touch(&x_trash, &y_trash)) {}
        //check which option the user pressed
        if((x_position >= 35 && x_position <= 90) && (y_position >= 101 && y_position <=121)) {
            //width = 106 px
            //clear the screen
            ClearScreen();
            //play game menu
            Play(money);
        }
        else if((x_position >= 5 && x_position <= 124) && (y_position >= 131 && y_position <=146)) {
            //clear the screen
            ClearScreen();
            //display game stats
            Stats(money, fish, descentLevel, horizontalLevel, valueLevel, region);
        }
        else if((x_position >= 2 && x_position <= 132) && (y_position >= 151 && y_position <=166)) {
            //clear the screen
            ClearScreen();
            //display instructions
            Rule(1);
        }
        else if((x_position >= 5 && x_position <= 102) && (y_position >= 171 && y_position <=186)) {
            //clear the screen
            ClearScreen();
            //collection
            collection(1);
        }
        else if((x_position >= 25 && x_position <= 106) && (y_position >= 191 && y_position <=206)) {
            //clear the screen
            ClearScreen();
            //display credits
            Credits();
        }
        else {
            Menu();
        }
    }
}
void Play(float money) {
    //declare variables for touch
    float x_position, y_position, x_trash, y_trash, bobber_x=155, bobber_y=0,curTime;
    int region;
    selectRegion(&region);
    //draw backgroud of region
    drawBackground(region);
    //print click to start
    LCD.SetFontColor(WHITE);
    LCD.WriteAt("Click to start", 80, 111);
    //LCD.WriteAt("Return to main menu", 40, 210);

    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}

    FEHImage bobber;
    bobber.Open("bobber2FEH.pic");
    bobber.Draw(bobber_x,bobber_y);
    Sleep(.5);
    //clear touch buffer
    LCD.ClearBuffer();
    /*move bobber down over time while also looking for user input*/
    while(bobber_y<220){

        drawBackground(region);

        //if screen touched, move left or right
        if(LCD.Touch(&x_position, &y_position)){
            //maybe drawbackground function here? or fish?

            //if user touches to the right of bobber, move right. if user touches to
            //the left, move left
            if(x_position>=bobber_x){
                //should replace value with users horizontal speed value
                bobber_x+=.5;
            }else if(x_position<bobber_x){
                bobber_x-=.5;
            }
        }
        //amount added should be replaced with descent speed
        drawFishPond(1,0,0);
        bobber_y+=.5;
        bobber.Draw(bobber_x,bobber_y);
        //draw the fishing line
        LCD.DrawLine(bobber_x+4,0,bobber_x+4,bobber_y);
        Sleep(.001);
        LCD.ClearBuffer();
    }
    //display a results screen
    LCD.SetFontColor(BLACK);
    LCD.FillRectangle(40,40,240,160);
    LCD.SetFontColor(WHITE);
    LCD.WriteAt("No fish Caught",40,41);
    LCD.WriteAt("Money Gained: ",40,66);
    LCD.SetFontColor(GREEN);
    LCD.WriteAt(money,210,65);
    LCD.SetFontColor(WHITE);
    //sleep for 2 seconds so that the results screen is not skipped
    Sleep(2.0);
    LCD.ClearBuffer();
    //this creates a click to continue once the bobber movement loop has been completed.
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}

    //this is for the placeholder play game screen
    /*
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    //return to main menu
    if((x_position >= 40 && x_position <= 270) && (y_position >= 210 && y_position <=220)) {
        bobber.Close();
        printf("bobber closed");
        Menu();
    }
    else{
        printf("moved");
        //ClearScreen();
        bobber_x +=10;
        Play();
    }
    */
}

void selectRegion(int* region) {
    //declare variables for touch
    float x_position, y_position, x_trash, y_trash;
    drawBackground(0);

    //print click to start
    LCD.SetFontColor(BLACK);
    LCD.WriteAt("Select", 15, 31);
    LCD.WriteAt("Region", 60, 56);
    LCD.WriteAt("Pond", 41, 121);
    LCD.WriteAt("River", 37, 151);
    LCD.WriteAt("Sea", 45, 181);
    drawHome(280, 200);

    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}

    //return to main menu
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        Menu();
    }
    else if((x_position >= 41 && x_position <= 88) && (y_position >= 121 && y_position <=136)){
        //stay in stats
        *region = 1;
    }
    else if((x_position >= 37 && x_position <= 98) && (y_position >= 151 && y_position <=166)) {
        *region = 2;
    }
    else if((x_position >= 45 && x_position <= 82) && (y_position >= 181 && y_position <=196)) {
        *region = 3;
    }
    else {
        selectRegion(region);
    }

}
void Stats(float money, int fish, int descentLevel, int horizontalLevel, int valueLevel, int region) {
    //declare variables for touch
    float x_position, y_position, x_trash, y_trash;
    //display all the stats
    LCD.SetFontColor(WHITE);
    LCD.WriteAt("Statistics", 90, 5);
    LCD.WriteAt("Money: $", 40, 50);
    LCD.SetFontColor(GREEN);
    LCD.WriteAt(money, 150, 50);
    LCD.SetFontColor(WHITE);
    LCD.WriteAt("Fish caught: ", 40, 70);
    LCD.WriteAt(fish, 190, 70);
    LCD.WriteAt("Descent Level: ", 40, 90);
    LCD.WriteAt(descentLevel, 210, 90);
    LCD.WriteAt("Speed Level: ", 40, 110);
    LCD.WriteAt(horizontalLevel, 190, 110);
    LCD.WriteAt("Value x: ", 40, 130);
    LCD.WriteAt(valueLevel, 150, 130);
    LCD.WriteAt("Region: ", 40, 150);
    LCD.WriteAt(region, 130, 150);
    drawHome(280, 200);

    Sleep(.5);
    //clear touch buffer
    LCD.ClearBuffer();
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    //return to main menu
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        Menu();
    }
    else {
        //stay in stats
        Stats(money, fish, descentLevel, horizontalLevel, valueLevel, region);
    }
}
void Rule(int page) {
    //declare variable for touch
    float x_position, y_position, x_trash, y_trash;
    int nextXPos=220,previousXPos=40;
    //this was causing it to print instructions in the terminal? weird
    //printf(page + "\n");
    LCD.SetFontColor(WHITE);
    LCD.WriteAt("Instructions", 90, 5);
    drawHome(280, 200);
    //font color blue to differentiate buttons
    LCD.SetFontColor(BLUEVIOLET);
    if(page < 3) {
        LCD.WriteAt("Next",nextXPos,190);
    }
    if(page != 1){
        LCD.WriteAt("Back",previousXPos,190);
    }
    //clear any instructions that were on screen
    //LCD.SetFontColor(BLACK);
    //drawInstruction(page-1);
    //LCD.SetFontColor(BLACK);
    //drawInstruction(page+1);
    //display current page of instructions
    LCD.SetFontColor(WHITE);
    drawInstruction(page);
    Sleep(.5);
    //clear touch buffer
    LCD.ClearBuffer();
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    //return to main menu
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        Menu();
    }else if((x_position>=nextXPos && x_position<=nextXPos+50)&&(y_position>=190 && y_position<=200)&&(page<3)){
        //increment page number IF click within region and if maximum page is not reached
        page++;
        ClearScreen();
        Rule(page);
    }else if((x_position>=previousXPos && x_position<=previousXPos+50)&&(y_position>=190 && y_position<=200)&&(page>1)){
        //decrement page number IF click within region and if minimum page is not reached
        page--;
        ClearScreen();
        Rule(page);
    }else {
        Rule(page);
    }
}
void collection(int page) {
    //declare variable for touch
    float x_position, y_position, x_trash, y_trash;
    int nextXPos=260,previousXPos=15;
    drawBackground(page);
    //this was causing it to print instructions in the terminal? weird
    //printf(page + "\n");
    LCD.SetFontColor(BLACK);
    drawHome(280, 200);
    //font color blue to differentiate buttons
    LCD.SetFontColor(BLUEVIOLET);
    if(page < 3) {
        LCD.WriteAt("Next",nextXPos,5);
    }
    if(page > 1){
        LCD.WriteAt("Back",previousXPos,5);
    }
    
    LCD.SetFontColor(BLACK);
    switch (page)
    {
    case 1:
        pondCollection();
        break;
    case 2:
        riverCollection();
        break;
    case 3:
        seaCollection();
        break;
    
    default:
        break;
    }

    Sleep(.5);
    //clear touch buffer
    LCD.ClearBuffer();
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    //return to main menu
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        Menu();
    }else if((x_position>=nextXPos && x_position<=nextXPos+50)&&(y_position>=5 && y_position<=20)&&(page<3)){
        //increment page number IF click within region and if maximum page is not reached
        page++;
        ClearScreen();
        collection(page);
    }else if((x_position>=previousXPos && x_position<=previousXPos+50)&&(y_position>=5 && y_position<=20)&&(page>1)){
        //decrement page number IF click within region and if minimum page is not reached
        page--;
        ClearScreen();
        collection(page);
    }else {
        collection(page);
    }
}
void pondCollection() {
    LCD.WriteAt("POND", 140, 5);
    int num = 1, x = 15, y = 110;
    for(int i = 0; i < 3; i++) {
        drawFishPond(num, x, y);
        num++;
        y += 30;
    }
    x+= 80;
    y=110;
    for(int i = 0; i < 3; i++) {
        drawFishPond(num, x, y);
        num++;
        y += 30;
    }

    x+= 80;
    y=110;
    for(int i = 0; i < 3; i++) {
        drawFishPond(num, x, y);
        num++;
        y += 30;
    }

    x+= 80;
    y=110;
    for(int i = 0; i < 3; i++) {
        drawFishPond(num, x, y);
        num++;
        y += 30;
    }
    
}

void seaCollection() {
    LCD.WriteAt("SEA", 145, 5);
}

void riverCollection() {
    LCD.WriteAt("RIVER", 130, 5);
}

void Credits() {
    //declare variables for touch
    float x_position, y_position, x_trash, y_trash;
    //display developer names
    LCD.SetFontColor(WHITE);
    LCD.WriteAt("Developers", 94, 31);
    LCD.WriteAt("Evan Davis", 94, 91);
    LCD.WriteAt("JJ Kiratikosolrak", 60, 121);
    drawHome(280, 200);
    Sleep(.5);
    //clear touch buffer
    LCD.ClearBuffer();
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    //return to main menu
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        Menu();
    }
    else {
        Credits();
    }
}
void drawHome(int x, int y) {
    FEHImage home;
    home.Open("homeFEH.pic");
    home.Draw(x, y);
    home.Close();
}
void ClearScreen() {
    // Clear background
    LCD.SetBackgroundColor(BLACK);
    LCD.Clear();
    LCD.Update();
    // LCD.SetFontColor(BLACK);
    // LCD.FillRectangle(0, 0, 319, 239);
    // LCD.SetFontColor(WHITE);
    // LCD.Update();
}
void drawInstruction(int page){
    //print the instructions for the corresponding page. starts at y=30 and goes to y=165
    //i love no auto wraparound text!
    //15 pixel line spacing
    switch(page){
        case 1:
            LCD.WriteAt("To play, touch play on",10,30);
            LCD.WriteAt("the main menu. Your goal",10,45);
            LCD.WriteAt("is to guide the bobber to",10,60);
            LCD.WriteAt("a fish before the time",10,75);
            LCD.WriteAt("runs out or the bobber",10,90);
            LCD.WriteAt("reaches the bottom. You",10,105);
            LCD.WriteAt("will receive more money",10,120);
            LCD.WriteAt("depending on how much",10,135);
            LCD.WriteAt("the fish is worth. More",10,150);
            LCD.WriteAt("valuable fish are below.",10,165);
            LCD.WriteAt("1",145,190);
            break;
        case 2:
            LCD.WriteAt("You will accumulate money",10,30);
            LCD.WriteAt("over time, which can be",10,45);
            LCD.WriteAt("spent on various upgrades.",10,60);
            LCD.WriteAt("Upgrades increase the",10,75);
            LCD.WriteAt("speed of descent, the",10,90);
            LCD.WriteAt("horizontal speed, the",10,105);
            LCD.WriteAt("value of fish, and the",10,120);
            LCD.WriteAt("area you are in. Upgrades",10,135);
            LCD.WriteAt("get more expensive as",10,150);
            LCD.WriteAt("they are purchased.",10,165);
            LCD.WriteAt("2",145,190);
            break;
        case 3:
            LCD.WriteAt("Every unique fish that is",10,30);
            LCD.WriteAt("caught is added to a",10,45);
            LCD.WriteAt("collection which can be ",10,60);
            LCD.WriteAt("viewed from the menu.",10,75);
            LCD.WriteAt("Each fish has its own",10,90);
            LCD.WriteAt("entry with information",10,105);
            LCD.WriteAt("and facts about it.",10,120);
            LCD.WriteAt(" ",10,135);
            LCD.WriteAt(" ",10,150);
            LCD.WriteAt(" ",10,165);
            LCD.WriteAt("3",145,190);
            break;
    }
}
/*by Evan D. This function takes an integer input for a corresponding background image
1 is main menu background, 2 is sea/beach background, 3 is pond background, 4 is
river background*/
void drawBackground(int BGnum){
    FEHImage BG;
    switch(BGnum){
        case 0:
            BG.Open("mainFEH.pic");
            break;
        case 1:
            BG.Open("Pond-bgFEH.pic");
            break;
        case 2:
            BG.Open("River-bgFEH.pic");
            break;
        case 3:
            BG.Open("Beach-bgFEH.pic");
            break;
    }
    BG.Draw(0,0);
    BG.Close();
}
/* by Evan D. Takes 3 integer inputs, 1 for the fish image to draw and the other two are the coordinates to draw at.
The integers that correspond to fish are listed in each element of the switch case. */
void drawFishPond(int fishNum,int x,int y){
    FEHImage Fish;
    switch(fishNum){
        case 1:
            //carp
            Fish.Open("M_Carp_FEH.pic");
            break;
        case 2:
            //catfish
            Fish.Open("M_Catfish_FEH.pic");
            break;
        case 3:
            //crawfish
            Fish.Open("S_Crawfish_FEH.pic");
            break;
        case 4:
            //frog
            Fish.Open("S_Frog_FEH.pic");
            break;
        case 5:
            //gar
            Fish.Open("L_Gar_FEH.pic");
            break;
        case 6:
            //giant snakehead
            Fish.Open("M_Giant_Snakehead_FEH.pic");
            break;
        case 7:
            //Goldfish
            Fish.Open("S_Goldfish_FEH.pic");
            break;
        case 8:
            //killifish
            Fish.Open("S_Killifish_FEH.pic");
            break;
        case 9:
            //koi
            Fish.Open("M_Koi_FEH.pic");
            break;
        case 10:   
            //pop eyed goldfish
            Fish.Open("S_Pop-Eyed_Goldfish_FEH.pic");
            break;
        case 11:
            //ranchu goldfish
            Fish.Open("S_Ranchu_Goldfish_FEH.pic");
            break;

        case 12:
            //tadpole
            Fish.Open("S_Tadpole_FEH.pic");
            break;
    }
    Fish.Draw(x,y);
    Fish.Close();

}
void drawFishRiver(int fishNum,int x,int y){
    FEHImage Fish;
    switch(fishNum){
        case 1:
            //angelfish
            Fish.Open("S_Angelfish_FEH.pic");
            break;
        case 2:
            //Arapaima
            Fish.Open("L_Arapaima_FEH.pic");
            break;
        case 3:
            //arowana
            Fish.Open("M_Arowana_FEH.pic");
            break;
        case 4:
            //betta
            Fish.Open("S_Betta_FEH.pic");
            break;
        case 5:
            //Dorado
            Fish.Open("L_Dorado_FEH.pic");
            break;
        case 6:
            //freshwater goby
            Fish.Open("S_Freshwater_Goby_FEH.pic");
            break;
        case 7:
            //golden trout
            Fish.Open("M_Golden_Trout_FEH.pic");
            break;
        case 8:
            //neon
            Fish.Open("S_Neon_FEH.pic");
            break;
        case 9:
            //pale chub
            Fish.Open("S_Pale_Chub_FEH");
            break;
        case 10:
            //piranha
            Fish.Open("S_Piranha_FEH.pic");
            break;
        case 11:
            //saddled
            Fish.Open("M_Saddled_FEH.pic");
            break;
        case 12:
            //salmon
            Fish.Open("M_Salmon_FEH");
            break;
        case 13:
            //snapping turtle
            Fish.Open("M_Snapping_Turtle_FEH.pic");
            break;
        case 14:
            //strugeon
            Fish.Open("L_Sturgeon_FEH.pic");
            break;
        case 15:
            //tilapia
            Fish.Open("M_Tilapia_FEH.pic");
            break;
    }
    Fish.Draw(x,y);
    Fish.Close();

}

void drawFishSea(int fishNum,int x,int y){
    FEHImage Fish;
    switch(fishNum){
        case 1:
            //blowfish
            Fish.Open("M_Blowfish_FEH.pic");
            break;
        case 2:
            //butterfly fish
            Fish.Open("S_Butterfly_Fish_FEH.pic");
            break;
        case 3:
            //clown fish
            Fish.Open("S_Clown_Fish_FEH.pic");
            break;
        case 4:
            //coelacanth
            Fish.Open("L_Coelacanth_FEH.pic");
            break;
        case 5:
            //dab
            Fish.Open("M_Dab_FEH.pic");
            break;
        case 6:
            //great white shark
            Fish.Open("L_Great_White_Shark_FEH.pic");
            break;
        case 7:
            //napoleonfish
            Fish.Open("L_Napoleonfish_FEH.pic");
            break;
        case 8:
            //ocean sunfish
            Fish.Open("L_Ocean_Sunfish_FEH.pic");
            break;
        case 9:
            //red snapper
            Fish.Open("M_Red_Snapper_FEH.pic");
            break;
        case 10:
            //saw shark
            Fish.Open("L_Saw_Shark_FEH.pic");
            break;
        case 11:
            //sea horse
            Fish.Open("S_Sea_Horse_FEH.pic");
            break;
        
        case 12:
            //squid
            Fish.Open("M_Squid_FEH.pic");
            break;
        case 13:
            //Suckerfish
            Fish.Open("L_Suckerfish_FEH.pic");
            break;
        case 14:
            //surgeonfish
            Fish.Open("S_Surgeonfish_FEH.pic");
            break;
        case 15:
            //whale shark
            Fish.Open("L_Whale_Shark_FEH.pic");
            break;
    }
    Fish.Draw(x,y);
    Fish.Close();

}

int main() {
    // Clear background
    LCD.SetBackgroundColor(BLACK);
    LCD.Clear();
    Menu();
    while (1) {
        LCD.Update();
        // Never end
    }
    return 0;
}