#include "FEHLCD.h"
#include "FEHUtility.h"
#include "FEHRandom.h"
#include "FEHImages.h"
#include <string.h>
#include <math.h>
#include <fstream>
#include <iostream>
#include <vector>
#include <FEHRandom.h>
using namespace std;

/*this class creates a way to access and change the users values. a single variable can be created with this class
and can be passed by reference to all functions where it will be used.*/
class userStats{
    public:
        userStats(int m = 0, int f = 0, int d = 1, int h = 1, int v = 1);
        int getLevel(char which);
        void changeLevel(char level, int amount);
        void incrementFish();
        int getMoney();
        int getFishCaught();
        int getDescentLevel();
        int getHorizontalLevel();
        int getValue();
        void resetStats();

    private:
        int money, fishCaught, descentLevel, horizontalLevel, value;
};

/*by Evan D. this function initializes the values within the class.*/
userStats::userStats(int m, int f, int d, int h, int v){
    //constructor; initialize values of money and levels
    money=m;
    fishCaught=f;
    descentLevel=d;
    horizontalLevel=h;
    value=v;
}

/*by Evan D. this function returns the value of the users stats depending on a char input. input chars are as follows: m is for money, d is for 
descentLevel, h is for horizontalLevel, and v is for verticalLevel*/
int userStats::getLevel(char level){
    switch(level){
        case 'm':
            return money;
            break;
        case 'd':
            return descentLevel;
            break;
        case 'h':
            return horizontalLevel;
            break;
        case 'v':
            return value;
            break;
    }
}

void userStats::incrementFish(){
    fishCaught++;
}

int userStats::getMoney(){
    return money;
}

int userStats::getDescentLevel() {
    return descentLevel;
}

int userStats::getFishCaught() {
    return fishCaught;
}

int userStats::getHorizontalLevel() {
    return horizontalLevel;
}

int userStats::getValue() {
    return value;
}

void userStats::resetStats(){
    money=0;
    fishCaught=0;
    descentLevel=1;
    horizontalLevel=1;
    value=1;
}

/*by Evan D. this function changes the values within a class. it takes a char input which corresponds
to the value it will change by the int input amount. input chars are as follows: m is for money, d is for 
descentLevel, h is for horizontalLevel, and v is for verticalLevel*/
void userStats::changeLevel(char level, int amount){
    switch(level){
        case 'm':
            money+=amount;
            break;
        case 'd':
            descentLevel+=amount;
            break;
        case 'h':
            horizontalLevel+=amount;
            break;
        case 'v':
            value+=amount;
            break;
    }
}

void Menu(userStats &user);
void Play(userStats &user);
void selectRegion(int* r, userStats &user);
void Stats(userStats &user, int f);
void Rule(int page, userStats &user);
void Credits(userStats &user);
void ClearScreen();
void drawInstruction(int page);
bool collision(int x11, int x12, int y11, int y12, int x21, int x22, int y21, int y22, int r);
void drawBackground(int BGnum);
void drawFishPond(char* pond,int x,int y);
void drawFishRiver(char* river, int x,int y);
void drawFishSea(char* sea,int x,int y);
void drawArrow(int d, int x, int y);
void collection(int page, userStats &user);
void pondCollection(int page);
void riverCollection(int page);
void seaCollection(int page);
void getPondName(int fishNum, int x, int y);
void getRiverName(int fishNum, int x, int y);
void getSeaName(int fishNum, int x, int y);
void drawHome(int x, int y);
void drawResultScreen(int whichFish, userStats &user, int price[], int fish[]);
void recordFishCaught(int region, int fishNum);
void recordStats(userStats &user);
void getWidth(char name[][50], int* width, int size);
bool checkFishCaught(int region, int fishNum);
void drawSetting(int x, int y);
void setSettingScreen(userStats &user);

/*by Evan D and JJ K. this function draws the main menu and checks for the user to click somewhere on the screen*/
void Menu(userStats &user) {
    //set variables
    float x_position, y_position, x_trash, y_trash;
    //float money = 0;
    int fish = 0, descentLevel = 1, horizontalLevel = 1, valueLevel = 1, region = 1;
    FEHImage play;
    
    while(1) {
        //clear screen
        //ClearScreen();
        drawBackground(0);
        // FEHImage tilapia;
        // tilapia.Open("TilapiaFEH.pic");
        // tilapia.Draw(0,0);
        // tilapia.Close();
        LCD.SetFontColor(BLACK);
        //display main menu middle top screen
        LCD.WriteAt("Fishing", 15, 31);
        LCD.WriteAt("SIM", 90, 61);
        //LCD.WriteAt("Play Game", 10, 111);
        play.Open("Play-ButtonFEH.pic");
        play.Draw(35, 101);
        play.Close();
        LCD.WriteAt("Statistics", 5, 131);
        LCD.WriteAt("How to Play", 2, 151);
        LCD.WriteAt("Collection",5,171);
        LCD.WriteAt("Credits", 25, 191);
        drawSetting(280, 200);

        

        Sleep(.5);
        //clear touch buffer
        LCD.ClearBuffer();
        //wait till user touches the screen
        while(!LCD.Touch(&x_position, &y_position)) {}
        //wait until the touch releases
        while(LCD.Touch(&x_trash, &y_trash)) {}
        //check which option the user pressed
        if((x_position >= 35 && x_position <= 90) && (y_position >= 101 && y_position <=121)) {
            //width = 106 px
            //clear the screen
            ClearScreen();
            //play game menu
            Play(user);
        }
        else if((x_position >= 5 && x_position <= 124) && (y_position >= 131 && y_position <=146)) {
            //clear the screen
            ClearScreen();
            //display game stats
            Stats(user, fish);
        }
        else if((x_position >= 2 && x_position <= 132) && (y_position >= 151 && y_position <=166)) {
            //clear the screen
            ClearScreen();
            //display instructions
            Rule(1, user);
        }
        else if((x_position >= 5 && x_position <= 102) && (y_position >= 171 && y_position <=186)) {
            //clear the screen
            ClearScreen();
            //collection
            collection(1, user);
        }
        else if((x_position >= 25 && x_position <= 106) && (y_position >= 191 && y_position <=206)) {
            //clear the screen
            ClearScreen();
            //display credits
            Credits(user);
        }
        else if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
            //clear the screen
            ClearScreen();
            //display setting
            setSettingScreen(user);
        }
        else {
            Menu(user);
        }
        recordStats(user);
    }
}
/*by Evan D and JJ K. this function sets up the play cycle for the user, which consists of a few steps.
first, the user is presented with a choice to select their region. 
second, random coordinates for the fish will be chosen and checked to make sure each fish' size does not overlap with another.
then the background, fish, and bobber will be drawn in that order
the bobber will then move down the screen while looking for user input on either side of it, as
well as making sure the bobber is not at the bottom of the screen or has collided with a fish. the drawing process is 
repeated after each check
a results screen will be created with how much money the user has gained and what to do to proceed.*/
void Play(userStats &user) {
    //declare variables for touch
    float x_position, y_position, x_trash, y_trash, bobber_x=155, bobber_y=0,curTime;
    int fishSize = 12, whichFish=-1;
    bool fishCaught=false;

    char pondFish[12][50] = {"M_Carp_FEH.pic", "M_Catfish_FEH.pic", "S_Crawfish_FEH.pic", "S_Frog_FEH.pic", "L_Gar_FEH.pic", "M_Giant_Snakehead_FEH.pic", "S_Goldfish_FEH.pic", "S_Killifish_FEH.pic", "M_Koi_FEH.pic", "S_Tadpole_FEH.pic", "S_Pop-Eyed_Goldfish_FEH.pic", "S_Ranchu_Goldfish_FEH.pic"};
    int pondPrice[] = {300, 800, 200, 120, 6000, 5500, 1300, 300, 4000, 1300, 4500, 100};
    char riverFish[15][50] = {"S_Angelfish_FEH.pic", "L_Arapaima_FEH.pic", "M_Arowana_FEH.pic", "S_Betta_FEH.pic", "L_Dorado_FEH.pic", "S_Freshwater_Goby_FEH.pic", "M_Golden_Trout_FEH.pic", "S_Neon_FEH.pic", "S_Pale_Chub_FEH.pic", "S_Piranha_FEH.pic", "M_Saddled_FEH.pic", "M_Salmon_FEH.pic", "M_Snapping_Turtle_FEH.pic", "L_Sturgeon_FEH.pic", "M_Tilapia_FEH.pic"};
    int riverPrice[] = {3000, 10000, 10000, 2500, 15000, 400, 15000, 500, 200, 2500, 4000, 700, 5000, 10000, 800};
    char seaFish[15][50] = {"M_Blowfish_FEH.pic", "S_Butterfly_Fish_FEH.pic", "S_Clown_Fish_FEH.pic", "L_Coelacanth_FEH.pic", "M_Dab_FEH.pic", "L_Great_White_Shark_FEH.pic", "L_Napoleonfish_FEH.pic", "L_Ocean_Sunfish_FEH.pic", "M_Red_Snapper_FEH.pic", "L_Saw_Shark_FEH.pic", "S_Sea_Horse_FEH.pic", "M_Squid_FEH.pic", "L_Suckerfish_FEH.pic", "S_Surgeonfish_FEH.pic", "L_Whale_Shark_FEH.pic"};
    int seaPrice[] = {5000, 1000, 650, 15000, 300, 15000, 10000, 4000, 3000, 12000, 500, 500, 1500, 1000, 1300};
   

    int region;
    //select region screen
    selectRegion(&region, user);
    //draw backgroud of region
    drawBackground(region);
    //set counter variables
    int maxL = 2, l = 0, maxM = 4, m = 0;
    int yStart = 110, xStart = 20, xEnd = 320, yEnd = 230;
    int fish[fishSize], limit = 15;
    int width[fishSize];
    //only 12 fishes in pond
    if(region == 1) {
        limit = 12;
    }
    //get name
    char name[50];
    for(int i = 0; i < fishSize; i++) {
        //randomly generate fish
        fish[i] = Random.RandInt()%limit;
        //get fish name from different region
        if(region == 1) {
            strcpy(name, pondFish[fish[i]]);
        }
        else if(region == 2) {
            strcpy(name, riverFish[fish[i]]);
        }
        else if(region == 3) {
            strcpy(name, seaFish[fish[i]]);
        }
        //get the size of the fish
        if(name[0] == 'S') {
            width[i] = 20;
        }
        else if(name[0] == 'M') {
            //limit number of medium fishes, so the game can fit more fish
            m++;
            width[i] = 30;
            if(m > maxM) {
                i--;
            }
        }
        else if(name[0] == 'L') {
            //limit number of large fishes, so the game can fit more fish
            l++;
            width[i] = 45;
            if(l > maxL) {
                i--;
            }
        }
    }

    //declare and initialize counter variables
    int xyStart[fishSize][2];
    int xyEnd[fishSize][2];
    bool fit;
    int x1, x2, y1, y2, num =0, buffer = 10, distance, xCenter1, xCenter2, yCenter1, yCenter2, r;
    //randomly generated x and y coordinates of each fish
    while(num < fishSize) {
        //generate random coordinate
        x1 = xStart + Random.RandInt()%(xEnd-width[num]-xStart+1);
        x2 = x1 + width[num];
        y1 = yStart + Random.RandInt()%(yEnd-width[num]-yStart+1);
        y2 = y1 + width[num];
        //LCD.SetFontColor(BLACK);
        //LCD.DrawRectangle(x1, y1, width[num], width[num]);
        fit = true;

        //check that the fish will not overlap with previous fish
        for(int n = 0; n < num && fit; n++){
            if(width[n] > width[num]) {
                r = width[n];
            }
            else {
                r = width[num];
            }
            //if both coordinate collide, then the fish overlap
            if (collision(x1, x2, y1, y2, xyStart[n][0], xyEnd[n][0], xyStart[n][1], xyEnd[n][1], r)) {
                fit = false;
            }
        }
        //the fish coordinate cannot be more/less than the grid
        if(x1 < xStart || x2 > xEnd) {
            fit = false;
        }
        if(y1 < yStart || y2 > yEnd) {
            fit = false;
        }

        //if the coordinate meet all above requirement, store it as a pair of coordinate
        if(fit) {
            xyStart[num][0] = x1;
            xyStart[num][1] = y1;
            xyEnd[num][0] = x2;
            xyEnd[num][1] = y2;
            num++;
        }
    }

    //print click to start
    LCD.SetFontColor(BLACK);
    LCD.WriteAt("Click to start", 80, 111);

    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    

    FEHImage bobber;
    bobber.Open("bobber2FEH.pic");
    bobber.Draw(bobber_x,bobber_y);
    Sleep(.5);
    //clear touch buffer
    LCD.ClearBuffer();
    /*move bobber down over time while also looking for user input*/
    while(bobber_y<220){

        drawBackground(region);

        //draw the fish from different region in randomly generated coordinate pairs
        for(int i = 0; i < fishSize; i++) {
            if(region == 1) {
                drawFishPond(pondFish[fish[i]], xyStart[i][0], xyStart[i][1]);
            }
            else if(region == 2) {
                drawFishRiver(riverFish[fish[i]], xyStart[i][0], xyStart[i][1]);
            }
            else if(region == 3) {
                drawFishSea(seaFish[fish[i]], xyStart[i][0], xyStart[i][1]);
            }
        }

        //if screen touched, move left or right
        if(LCD.Touch(&x_position, &y_position)){
            //if user touches to the right of bobber, move right. if user touches to
            //the left, move left
            if(x_position>=bobber_x){
                //users horizontal speed level impacts how fast it will move
                //bobber_x+=.5*money[2];
                bobber_x+=.5*user.getLevel('h');
            }else if(x_position<bobber_x){
                //bobber_x-=.5*money[2];
                bobber_x-=.5*user.getLevel('h');
            }
        }
        //amount added should be replaced with descent speed
        bobber_y+=.5*user.getLevel('d');
        bobber.Draw(bobber_x,bobber_y);
        //draw the fishing line
        LCD.DrawLine(bobber_x+4,0,bobber_x+4,bobber_y);
        Sleep(.01);
        LCD.ClearBuffer();

        //check collisions. fc is fish count
        for(int fc=0;fc<fishSize;fc++){
            /*if bobber collides with fish, set variable to exit while loop and exit for loop in case somehow collide with two fish
            radius is set to 10 in the collision check because the bobber is 10x10. can be changed if issues are found or if
            size changes*/
            //(width[fc]/2)-5
            if(collision(bobber_x,bobber_x+10,bobber_y,bobber_y+10, xyStart[fc][0], xyEnd[fc][0], xyStart[fc][1], xyEnd[fc][1], 10)){
                fishCaught=true;
                whichFish=fc;
                break;
            }
        }
        //break if a fish collides with bobber
        if(fishCaught){
            user.incrementFish();
            break;
        }
    }

    if(region==1){
        drawResultScreen(whichFish, user, pondPrice, fish);
    }else if(region==2){
        drawResultScreen(whichFish, user, riverPrice, fish);
    }else if(region==3){
        drawResultScreen(whichFish, user, seaPrice, fish);
    }
    if(fishCaught) {
        recordFishCaught(region, fish[whichFish]);
    }
    
}

void drawResultScreen(int whichFish, userStats &user, int price[], int fish[]) {
    float x_position, y_position, x_trash, y_trash;
    //display a results screen
    LCD.SetFontColor(BLACK);
    LCD.FillRectangle(40,40,240,160);
    LCD.SetFontColor(WHITE);
    if(whichFish!=-1){
        LCD.WriteAt("Fish Caught: ",40,41);
        //should replace this with name of fish
        //depending on region, print fish name and how much fish worth
        getPondName(fish[whichFish], 40, 61);
        user.changeLevel('m',user.getLevel('v')*price[fish[whichFish]]);
        LCD.SetFontColor(GREEN);
        LCD.WriteAt(user.getLevel('v')*price[fish[whichFish]],210,86);
        
        LCD.SetFontColor(WHITE);
    }else{
        LCD.WriteAt("No fish Caught",40,41);
        LCD.SetFontColor(RED);
        LCD.WriteAt("0",210,65);
        LCD.SetFontColor(WHITE);
    }
    
    LCD.WriteAt("Money Gained: ",40,86);
    LCD.WriteAt("Click to continue",40,156);
    
    //replace value of 10 with value of fish
    //use users value multiplier to multiply money gained

    //essentially: check string, return value for string. can use char input to determine if want to print name or print money value

    //sleep for 2 seconds so that the results screen is not skipped
    Sleep(2.0);
    LCD.ClearBuffer();
    //this creates a click to continue once the bobber movement loop has been completed.
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    
}
bool collision(int x11, int x12, int y11, int y12, int x21, int x22, int y21, int y22, int r){
    int xCenter1 = (x11+x12)/2;
    int yCenter1 = (y11+y12)/2;
    int xCenter2 = (x21 + x22)/2;
    int yCenter2 = (y21 + y22)/2;

    return abs(xCenter1 - xCenter2) < r && abs(yCenter1 - yCenter2) < r;
}
void selectRegion(int* region, userStats &user) {
    //declare variables for touch
    float x_position, y_position, x_trash, y_trash;
    drawBackground(0);

    //print click to start
    LCD.SetFontColor(BLACK);
    LCD.WriteAt("Select", 15, 31);
    LCD.WriteAt("Region", 60, 56);
    LCD.WriteAt("Pond", 41, 121);
    LCD.WriteAt("River", 37, 151);
    LCD.WriteAt("Sea", 45, 181);
    drawHome(280, 200);

    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}

    //return to main menu
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        Menu(user);
    }
    else if((x_position >= 41 && x_position <= 88) && (y_position >= 121 && y_position <=136)){
        *region = 1;
    }
    else if((x_position >= 37 && x_position <= 98) && (y_position >= 151 && y_position <=166)) {
        *region = 2;
    }
    else if((x_position >= 45 && x_position <= 82) && (y_position >= 181 && y_position <=196)) {
        *region = 3;
    }
    else {
        selectRegion(region, user);
    }

}
/*by Evan D. this function displays upgrades to the user as well as checks to see if they want
to upgrade something and if they can. depending on the users balance as well as their click location, 
a game modifier will be changed.*/
void Stats(userStats &user, int fish) {
    //declare variables for touch
    float x_position, y_position, x_trash, y_trash;
    //display all the stats
    LCD.SetFontColor(WHITE);
    LCD.WriteAt("Statistics", 90, 5);
    LCD.WriteAt("Money: $", 40, 50);
    LCD.SetFontColor(GREEN);
    LCD.WriteAt(user.getMoney(), 150, 50);
    LCD.SetFontColor(WHITE);
    LCD.WriteAt("Fish caught: ", 40, 70);
    LCD.WriteAt(user.getFishCaught(), 190, 70);
    LCD.WriteAt("Descent Level: ", 40, 90);
    LCD.WriteAt(user.getDescentLevel(), 210, 90);
    LCD.WriteAt(5000*user.getLevel('d'), 240, 90);
    LCD.WriteAt("Speed Level: ", 40, 110);
    LCD.WriteAt(user.getHorizontalLevel(), 190, 110);
    LCD.WriteAt(5000*user.getLevel('h'), 240, 110);
    LCD.WriteAt("Value x: ", 40, 130);
    LCD.WriteAt(user.getValue(), 150, 130);
    LCD.WriteAt(50000*user.getLevel('v'), 240, 130);
    drawHome(280, 200);

    Sleep(.5);
    //clear touch buffer
    LCD.ClearBuffer();
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    //depending on location of users touch, perform an action
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        Menu(user);
    }
    else if((x_position >= 250 && x_position <= 300) && (y_position >= 90 && y_position <=110)&&(user.getLevel('m')>=5000*user.getLevel('d'))&&(user.getLevel('d')<5)){
        //this statement upgrades descent speed if have enough money and less than max level.
        //remove money from users balance and then upgrade
        user.changeLevel('m',-5000*user.getLevel('d'));
        user.changeLevel('d',1);
        //replace fill rectangle if background created
        LCD.FillRectangle(0,0,320,240);
        Stats(user, fish);
    }
    else if((x_position >= 250 && x_position <= 300) && (y_position >= 111 && y_position <=130)&&(user.getLevel('m')>=5000*user.getLevel('h'))){
        //this statement upgrades horizontal speed if have enough money
        //remove money from users balance and then upgrade
        user.changeLevel('m',-5000*user.getLevel('h'));
        user.changeLevel('h',1);
        //replace fill rectangle if background created
        LCD.FillRectangle(0,0,320,240);
        Stats(user, fish);
    }
    else if((x_position >= 250 && x_position <= 300) && (y_position >= 131 && y_position <=150)&&(user.getLevel('m')>=50000*user.getLevel('v'))){
        //this statement upgrades value multiplier if have enough money
        //remove money from users balance and then upgrade
        user.changeLevel('m',-50000*user.getLevel('v'));
        user.changeLevel('v',1);
        //replace fill rectangle if background created
        LCD.FillRectangle(0,0,320,240);
        Stats(user, fish);
    }
    else {
        //stay in stats
        Stats(user, fish);
    }
}
void Rule(int page, userStats &user) {
    //declare variable for touch
    float x_position, y_position, x_trash, y_trash;
    int nextXPos=225,previousXPos=40;
    LCD.SetFontColor(WHITE);
    LCD.WriteAt("How to Play", 90, 5);
    drawHome(280, 200);
    //font color blue to differentiate buttons
    LCD.SetFontColor(BLUEVIOLET);
    if(page < 3) {
        drawArrow(2, nextXPos, 190);
    }
    if(page > 1){
        drawArrow(1, previousXPos, 190);
    }
    //display current page of instructions
    LCD.SetFontColor(WHITE);
    drawInstruction(page);
    Sleep(.5);
    //clear touch buffer
    LCD.ClearBuffer();
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    //return to main menu
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        Menu(user);
    }else if((x_position>=nextXPos && x_position<=nextXPos+29)&&(y_position>=190 && y_position<=217)&&(page<3)){
        //increment page number IF click within region and if maximum page is not reached
        page++;
        ClearScreen();
        Rule(page,user);
    }else if((x_position>=previousXPos && x_position<=previousXPos+29)&&(y_position>=190 && y_position<=217)&&(page>1)){
        //decrement page number IF click within region and if minimum page is not reached
        page--;
        ClearScreen();
        Rule(page,user);
    }else {
        Rule(page,user);
    }
}
void collection(int page, userStats &user) {
    //declare variable for touch
    float x_position, y_position, x_trash, y_trash;
    int nextXPos=276,previousXPos=15;
    if(page <= 2) {
        drawBackground(1);
    }
    else if(page <=6) {
        drawBackground(2);
    }
    else {
        drawBackground(3);
    }
    
    //this was causing it to print instructions in the terminal? weird
    //printf(page + "\n");
    LCD.SetFontColor(BLACK);
    drawHome(280, 200);
    //font color blue to differentiate buttons
    LCD.SetFontColor(BLUEVIOLET);
    if(page < 11) {
        //LCD.WriteAt("Next",nextXPos,5);
        drawArrow(2, nextXPos, 5);
    }
    if(page > 1){
        //LCD.WriteAt("Back",previousXPos,5);
        drawArrow(1, previousXPos, 5);
    }
    
    LCD.SetFontColor(BLACK);
    switch (page)
    {
    case 1:
        pondCollection(1);
        break;
    case 2:
        pondCollection(2);
        break;
    case 3:
        riverCollection(1);
        break;
    case 4:
        riverCollection(2);
        break;
    case 5:
        riverCollection(3);
        break;
    case 6:
        riverCollection(4);
        break;
    case 7:
        seaCollection(1);
        break;
    case 8:
        seaCollection(2);
        break;
    case 9:
        seaCollection(3);
        break;
    case 10:
        seaCollection(4);
        break;
    case 11:
        seaCollection(5);
        break;
    default:
        break;
    }

    Sleep(.5);
    //clear touch buffer
    LCD.ClearBuffer();
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    //return to main menu
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        Menu(user);
    }else if((x_position>=nextXPos && x_position<=nextXPos+29)&&(y_position>=5 && y_position<=32)&&(page<11)){
        //increment page number IF click within region and if maximum page is not reached
        page++;
        collection(page, user);
    }else if((x_position>=previousXPos && x_position<=previousXPos+29)&&(y_position>=5 && y_position<=32)&&(page>1)){
        //decrement page number IF click within region and if minimum page is not reached
        page--;
        collection(page, user);
    }else {
        collection(page, user);
    }
}
void pondCollection(int page) {
    LCD.WriteAt("POND", 140, 5);
    char pondFish[12][50] = {"M_Carp_FEH.pic", "M_Catfish_FEH.pic", "S_Crawfish_FEH.pic", "S_Frog_FEH.pic", "L_Gar_FEH.pic", "M_Giant_Snakehead_FEH.pic", "S_Goldfish_FEH.pic", "S_Killifish_FEH.pic", "M_Koi_FEH.pic", "S_Tadpole_FEH.pic", "S_Pop-Eyed_Goldfish_FEH.pic", "S_Ranchu_Goldfish_FEH.pic"};
    int width[12];
    getWidth(pondFish, width, 12);
    int num = 0, xStart = 15, yStart = 110, xNext = 150, yNext = 40, region = 1;
    int x = xStart, y = yStart, w, buffer = 5, xText, yText;
    switch(page) {
        case 1:
            num = 0;
            for(int i = 0; i < 3; i++) {
                x = xStart;
                w = width[num] + buffer;
                for(int j = 0; j < 2; j++) {
                    if(width[num] > w) {
                        w = width[num] + buffer;
                    }
                    drawFishPond(pondFish[num], x, y);
                    if(checkFishCaught(region, num)) {
                        LCD.SetFontColor(BLUE);
                        LCD.DrawRectangle(x, y, width[num], width[num]);
                    }
                    //LCD.DrawRectangle(x, y, width[num], width[num]);
                    xText = x+width[num] + buffer;
                    yText = y + width[num]/4;
                    if(num == 5) {
                        LCD.WriteAt("Giant", xText, yText);
                        LCD.WriteAt("Snakehead", xText - width[num], yText + 20);
                    } else {
                        getPondName(num, xText, yText);
                    }
                    x += xNext;
                    num++;
                }
                y += w;
            }
            break;
        case 2:
            num = 6;
            for(int i = 0; i < 3; i++) {
                x = xStart;
                w = width[num] + buffer;
                for(int j = 0; j < 2; j++) {
                    if(width[num] > w) {
                        w = width[num] + buffer;
                    }
                    drawFishPond(pondFish[num], x, y);
                    if(checkFishCaught(region, num)) {
                        LCD.SetFontColor(BLUE);
                        LCD.DrawRectangle(x, y, width[num], width[num]);
                    }
                    //LCD.DrawRectangle(x, y, width[num], width[num]);
                    xText = x+width[num] + buffer;
                    yText = y + width[num]/4;
                    if(num == 10) {
                        LCD.WriteAt("Pop-Eyed", xText, yText);
                        LCD.WriteAt("GoldFish", xText - width[num] + buffer, yText + 20);
                    } 
                    else if(num == 11) {
                        LCD.WriteAt("Ranchu", xText, yText);
                        LCD.WriteAt("GoldFish", xText - width[num], yText + 20);
                    }
                    else {
                        getPondName(num, xText, yText);
                    }
                    x += xNext;
                    num++;
                }
                y += w;
            }
            break;
        default:
            break;
    }
    
}

void seaCollection(int page) {
    LCD.WriteAt("SEA", 145, 5);
    char seaFish[15][50] = {"M_Blowfish_FEH.pic", "S_Butterfly_Fish_FEH.pic", "S_Clown_Fish_FEH.pic", "L_Coelacanth_FEH.pic", "M_Dab_FEH.pic", "L_Great_White_Shark_FEH.pic", "L_Napoleonfish_FEH.pic", "L_Ocean_Sunfish_FEH.pic", "M_Red_Snapper_FEH.pic", "L_Saw_Shark_FEH.pic", "S_Sea_Horse_FEH.pic", "M_Squid_FEH.pic", "L_Suckerfish_FEH.pic", "S_Surgeonfish_FEH.pic", "L_Whale_Shark_FEH.pic"};
    int width[15];
    getWidth(seaFish, width, 15);
    int num = 0, xStart = 15, yStart = 115, xNext = 150, yNext = 10, xMiddle = 70, region = 3;
    int x = xStart, y = yStart, w, buffer = 5, buffer2 = 15, xText, yText;
    switch(page) {
        case 1:
            yNext = 30;
            num = 0;
            for(int i = 0; i < 2; i++) {
                x = xStart;
                w = width[num] + yNext;
                for(int j = 0; j < 2; j++) {
                    if(i < 1) {
                    drawFishSea(seaFish[num], x, y);
                    if(checkFishCaught(region, num)) {
                        LCD.SetFontColor(BLUE);
                        LCD.DrawRectangle(x, y, width[num], width[num]);
                    }
                    //LCD.DrawRectangle(x, y, width[num], width[num]);
                    xText = x+width[num] + buffer;
                    yText = y + width[num]/4;
                    if(num == 1) {
                        LCD.WriteAt("Butterfly", xText, yText);
                        LCD.WriteAt("Fish", xText + buffer2, yText + 20);
                    } else {
                        getSeaName(num, xText, yText);
                    }
                    }
                    else {
                        drawFishSea(seaFish[num], xMiddle, y);
                        if(checkFishCaught(region, num)) {
                            LCD.SetFontColor(BLUE);
                            LCD.DrawRectangle(xMiddle, y, width[num], width[num]);
                        }
                        xText = xMiddle+width[num] + buffer;
                        yText = y + width[num]/4;
                        getSeaName(num, xText, yText);
                        num++;
                        break;
                    }
                    x += xNext;
                    num++;
                    
                }
                y += w;
            }
            break;
        case 2:
            num = 3;
            yStart = 110, xNext = 190, yNext = 5, xMiddle = 60;
            for(int i = 0; i < 2; i++) {
                x = xStart;
                w = width[num] + yNext;
                for(int j = 0; j < 2; j++) {
                    if(i < 1) {
                    drawFishSea(seaFish[num], x, y);
                    if(checkFishCaught(region, num)) {
                        LCD.SetFontColor(BLUE);
                        LCD.DrawRectangle(x, y, width[num], width[num]);
                    }
                    //LCD.DrawRectangle(x, y, width[num], width[num]);
                    xText = x+width[num] + buffer;
                    yText = y + width[num]/4;
                    if(num == 1) {
                        LCD.WriteAt("Butterfly", xText, yText);
                        LCD.WriteAt("Fish", xText - width[num] + buffer, yText + 20);
                    } else {
                        getSeaName(num, xText, yText);
                    }
                    }
                    else {
                        drawFishSea(seaFish[num], xMiddle, y);
                        if(checkFishCaught(region, num)) {
                            LCD.SetFontColor(BLUE);
                            LCD.DrawRectangle(xMiddle, y, width[num], width[num]);
                        }
                        xText = xMiddle+width[num] + buffer;
                        yText = y + width[num]/4;
                        LCD.WriteAt("Great White", xText, yText);
                        LCD.WriteAt("Shark", xText + buffer2, yText + 20);
                        num++;
                        break;
                    }
                    x += xNext;
                    num++;
                    
                }
                y += w;
            }
            break;
        case 3:
            num = 6;
            yNext = 20;
            for(int i = 0; i < 2; i++) {
                x = xStart;
                w = width[num] + yNext;
                for(int j = 0; j < 2; j++) {
                    if(i < 1) {
                    drawFishSea(seaFish[num], x, y);
                    if(checkFishCaught(region, num)) {
                        LCD.SetFontColor(BLUE);
                        LCD.DrawRectangle(x, y, width[num], width[num]);
                    }
                    //LCD.DrawRectangle(x, y, width[num], width[num]);
                    xText = x+width[num] + buffer;
                    yText = y + width[num]/4;
                    if(num == 6) {
                        LCD.WriteAt("Napolean", xText, yText);
                        LCD.WriteAt("Fish", xText + buffer2, yText + 20);
                    } 
                    if(num == 7) {
                        LCD.WriteAt("Ocean", xText, yText);
                        LCD.WriteAt("Sunfish", xText + buffer2, yText + 20);
                    }
                    }
                    else {
                        drawFishSea(seaFish[num], xMiddle, y);
                        if(checkFishCaught(region, num)) {
                            LCD.SetFontColor(BLUE);
                            LCD.DrawRectangle(xMiddle, y, width[num], width[num]);
                        }
                        xText = xMiddle+width[num] + buffer;
                        yText = y + width[num]/4;
                        getSeaName(num, xText, yText);
                        num++;
                        break;
                    }
                    x += xNext;
                    num++;
                    
                }
                y += w;
            }
            break;
        case 4:
            num = 9;
            xMiddle = 110;
            for(int i = 0; i < 2; i++) {
                x = xStart;
                w = width[num] + yNext;
                for(int j = 0; j < 2; j++) {
                    if(i < 1) {
                        if(num == 10) {
                            y += buffer;
                        }
                    drawFishSea(seaFish[num], x, y);
                    if(checkFishCaught(region, num)) {
                        LCD.SetFontColor(BLUE);
                        LCD.DrawRectangle(x, y, width[num], width[num]);
                    }
                    //LCD.DrawRectangle(x, y, width[num], width[num]);
                    xText = x+width[num] + buffer;
                    yText = y + width[num]/4;
                    if(num == 9) {
                        LCD.WriteAt("Saw", xText, yText);
                        LCD.WriteAt("Shark", xText + buffer2, yText + 20);
                    } 
                    if(num == 10) {
                        LCD.WriteAt("Sea", xText, yText);
                        LCD.WriteAt("Horse", xText + buffer2, yText + 20);
                    }
                        
                    }
                    else {
                        drawFishSea(seaFish[num], xMiddle, y);
                        if(checkFishCaught(region, num)) {
                            LCD.SetFontColor(BLUE);
                            LCD.DrawRectangle(xMiddle, y, width[num], width[num]);
                        }
                        xText = xMiddle+width[num] + buffer;
                        yText = y + width[num]/4;
                        getSeaName(num, xText, yText);
                        num++;
                        break;
                    }
                    x += xNext;
                    num++;
                    
                }
                y += w;
            }
            break;   
        case 5:
            num = 12;
            yNext = 10;
            for(int i = 0; i < 2; i++) {
                x = xStart;
                w = width[num] + yNext;
                for(int j = 0; j < 2; j++) {
                    if(i < 1) {
                        if(num == 13) {
                            y += buffer;
                        }
                    drawFishSea(seaFish[num], x, y);
                    if(checkFishCaught(region, num)) {
                        LCD.SetFontColor(BLUE);
                        LCD.DrawRectangle(x, y, width[num], width[num]);
                    }
                    //LCD.DrawRectangle(x, y, width[num], width[num]);
                    xText = x+width[num] + buffer;
                    yText = y + width[num]/4;
                    if(num == 12) {
                        LCD.WriteAt("Sucker", xText, yText);
                        LCD.WriteAt("Fish", xText + buffer2, yText + 20);
                    } 
                    if(num == 13) {
                        LCD.WriteAt("Surgeon", xText, yText);
                        LCD.WriteAt("Sunfish", xText + buffer2, yText + 20);
                    }
                    }
                    else {
                        drawFishSea(seaFish[num], xMiddle, y);
                        if(checkFishCaught(region, num)) {
                            LCD.SetFontColor(BLUE);
                            LCD.DrawRectangle(xMiddle, y, width[num], width[num]);
                        }
                        xText = xMiddle+width[num] + buffer;
                        yText = y + width[num]/4;
                        getSeaName(num, xText, yText + buffer);
                        num++;
                        break;
                    }
                    x += xNext;
                    num++;
                    
                }
                y += w;
            }
            break;           
        default:
            break;
    }
}

void riverCollection(int page) {
    LCD.WriteAt("RIVER", 130, 5);
    char riverFish[15][50] = {"S_Angelfish_FEH.pic", "L_Arapaima_FEH.pic", "M_Arowana_FEH.pic", "S_Betta_FEH.pic", "L_Dorado_FEH.pic", "S_Freshwater_Goby_FEH.pic", "M_Golden_Trout_FEH.pic", "S_Neon_FEH.pic", "S_Pale_Chub_FEH.pic", "S_Piranha_FEH.pic", "M_Saddled_FEH.pic", "M_Salmon_FEH.pic", "M_Snapping_Turtle_FEH.pic", "L_Sturgeon_FEH.pic", "M_Tilapia_FEH.pic"};
    int width[15];
    getWidth(riverFish, width, 15);
    int num = 0, xStart = 15, yStart = 115, xNext = 150, yNext = 10, xMiddle = 70, region = 2;
    int x = xStart, y = yStart, w, buffer = 5, buffer2 = 15, xText, yText;
    switch(page) {
        case 1:
            num = 0, yNext = 10;
            for(int i = 0; i < 2; i++) {
                x = xStart;
                w = width[num] + buffer;
                for(int j = 0; j < 2; j++) {
                    if(width[num] > w) {
                        w = width[num] + buffer;
                    }
                    if(num == 0) {
                        y += buffer*2;
                    }
                    if(num == 1) {
                        y -= buffer;
                    }
                    if(num == 3) {
                        y += buffer;
                    }
                    drawFishRiver(riverFish[num], x, y);
                    if(checkFishCaught(region, num)) {
                        LCD.SetFontColor(BLUE);
                        LCD.DrawRectangle(x, y, width[num], width[num]);
                    }
                    //LCD.DrawRectangle(x, y, width[num], width[num]);
                    xText = x+width[num] + buffer;
                    yText = y + width[num]/4;
                    getRiverName(num, xText, yText);
                    x += xNext;
                    num++;
                }
                y += w;
            }
            break;
        case 2:
            num = 4, yNext = 20;
            for(int i = 0; i < 2; i++) {
                x = xStart;
                w = width[num] + buffer;
                for(int j = 0; j < 2; j++) {
                    if(width[num] > w) {
                        w = width[num] + buffer;
                    }
                    if(num ==7){
                        y +=buffer*2;
                    }
                    if(num == 5){
                        y +=buffer*2;
                    }
                    drawFishRiver(riverFish[num], x, y);
                    if(checkFishCaught(region, num)) {
                        LCD.SetFontColor(BLUE);
                        LCD.DrawRectangle(x, y, width[num], width[num]);
                    }
                    //LCD.DrawRectangle(x, y, width[num], width[num]);
                    xText = x+width[num] + buffer;
                    yText = y + width[num]/4;
                    if(num == 5) {
                        LCD.WriteAt("Freshwater", xText, yText);
                        LCD.WriteAt("Goby", xText + buffer, yText + 20);
                    } 
                    else if(num == 6) {
                        LCD.WriteAt("Golden", xText, yText);
                        LCD.WriteAt("Trout", xText + buffer, yText + 20);
                    }
                    else {
                        getRiverName(num, xText, yText);
                    }
                    x += xNext;
                    num++;
                }
                y += w;
            }
            break;
        case 3:
            num = 8, yNext = 30, y = 125;
            for(int i = 0; i < 2; i++) {
                x = xStart;
                w = width[num] + yNext;
                for(int j = 0; j < 2; j++) {
                    if(width[num] > w) {
                        w = width[num] + buffer;
                    }
                    if(num ==7){
                        y +=buffer*2;
                    }
                    if(num == 5){
                        y +=buffer*2;
                    }
                    drawFishRiver(riverFish[num], x, y);
                    if(checkFishCaught(region, num)) {
                        LCD.SetFontColor(BLUE);
                        LCD.DrawRectangle(x, y, width[num], width[num]);
                    }
                    //LCD.DrawRectangle(x, y, width[num], width[num]);
                    xText = x+width[num] + buffer;
                    yText = y + width[num]/4;
                    getRiverName(num, xText, yText);
                    x += xNext;
                    num++;
                }
                y += w;
            }
            break;
        case 4:
            num = 12, yNext = 20, y = 125, xMiddle = 100;
            for(int i = 0; i < 2; i++) {
                x = xStart;
                w = width[num] + yNext;
                for(int j = 0; j < 2; j++) {
                    if(i < 1) {
                    drawFishRiver(riverFish[num], x, y);
                    if(checkFishCaught(region, num)) {
                        LCD.SetFontColor(BLUE);
                        LCD.DrawRectangle(x, y, width[num], width[num]);
                    }
                    //LCD.DrawRectangle(x, y, width[num], width[num]);
                    xText = x+width[num] + buffer;
                    yText = y + width[num]/4;
                    if(num == 12) {
                        LCD.WriteAt("Snapping", xText, yText);
                        LCD.WriteAt("Turtle", xText + buffer2, yText + 20);
                    } 
                    else {
                        getRiverName(num, xText, yText);
                    }
                    }
                    else {
                        drawFishRiver(riverFish[num], xMiddle, y);
                        if(checkFishCaught(region, num)) {
                            LCD.SetFontColor(BLUE);
                            LCD.DrawRectangle(xMiddle, y, width[num], width[num]);
                        }
                        xText = xMiddle+width[num] + buffer;
                        yText = y + width[num]/4;
                        getRiverName(num, xText, yText + buffer);
                        num++;
                        break;
                    }
                    x += xNext;
                    num++;
                    
                }
                y += w;
            }
            break;
        default:
            break;
    }
}
/*By Evan D. the next 3 functions (getRegionName) all take an integer index value, and x and y coordinates.
It prints out the name of the fish without any file type at the end corresponding to the input index value.
it then writes the name on the screen at the x and y coordinates.*/
void getPondName(int fishNum, int x, int y){
    switch(fishNum){
        case 0:
            LCD.WriteAt("Carp",x,y);
            break;
        case 1:
            LCD.WriteAt("Catfish",x,y);
            break;
        case 2:
            LCD.WriteAt("Crawfish",x,y);
            break;
        case 3:
            LCD.WriteAt("Frog",x,y);
            break;
        case 4:
            LCD.WriteAt("Gar",x,y);
            break;
        case 5:
            LCD.WriteAt("Giant Snakehead",x,y);
            break;
        case 6:
            LCD.WriteAt("Goldfish",x,y);
            break;
        case 7:
            LCD.WriteAt("Killifish",x,y);
            break;
        case 8:
            LCD.WriteAt("Koi",x,y);
            break;
        case 9:
            LCD.WriteAt("Tadpole",x,y);
            break;
        case 10:
            LCD.WriteAt("Pop-Eyed Goldfish",x,y);
            break;
        case 11:
            LCD.WriteAt("Ranchu Goldfish",x,y);
            break;
        
    }
        
    
}
void getRiverName(int fishNum, int x, int y){
    switch(fishNum){
        case 0:
            LCD.WriteAt("Angelfish",x,y);
            break;
        case 1:
            LCD.WriteAt("Arapaima",x,y);
            break;
        case 2:
            LCD.WriteAt("Arowana",x,y);
            break;
        case 3:
            LCD.WriteAt("Betta",x,y);
            break;
        case 4:
            LCD.WriteAt("Dorado",x,y);
            break;
        case 5:
            LCD.WriteAt("Freshwater Goby",x,y);
            break;
        case 6:
            LCD.WriteAt("Golden Trout",x,y);
            break;
        case 7:
            LCD.WriteAt("Neon",x,y);
            break;
        case 8:
            LCD.WriteAt("Pale Chub",x,y);
            break;
        case 9:
            LCD.WriteAt("Piranha",x,y);
            break;
        case 10:
            LCD.WriteAt("Saddled",x,y);
            break;
        case 11:
            LCD.WriteAt("Salmon",x,y);
            break;
        case 12:
            LCD.WriteAt("Snapping Turtle",x,y);
            break;
        case 13:
            LCD.WriteAt("Sturgeon",x,y);
            break;
        case 14:
            LCD.WriteAt("Tilapia",x,y);
            break;
    }
}
void getSeaName(int fishNum, int x, int y){
    switch(fishNum){
        case 0:
            LCD.WriteAt("Blowfish",x,y);
            break;
        case 1:
            LCD.WriteAt("Butterfly Fish",x,y);
            break;
        case 2:
            LCD.WriteAt("Clown Fish",x,y);
            break;
        case 3:
            LCD.WriteAt("Coelacanth",x,y);
            break;
        case 4:
            LCD.WriteAt("Dab",x,y);
            break;
        case 5:
            LCD.WriteAt("Great White Shark",x,y);
            break;
        case 6:
            LCD.WriteAt("Napoleon Fish",x,y);
            break;
        case 7:
            LCD.WriteAt("Ocean Sunfish",x,y);
            break;
        case 8:
            LCD.WriteAt("Red Snapper",x,y);
            break;
        case 9:
            LCD.WriteAt("Saw Shark",x,y);
            break;
        case 10:
            LCD.WriteAt("Sea Horse",x,y);
            break;
        case 11:
            LCD.WriteAt("Squid",x,y);
            break;
        case 12:
            LCD.WriteAt("Suckerfish",x,y);
            break;
        case 13:
            LCD.WriteAt("Surgeonfish",x,y);
            break;
        case 14:
            LCD.WriteAt("Whale Shark",x,y);
            break;
    }
}
void getWidth(char name[][50], int* width, int size) {
    for(int i = 0; i < size; i++) {
        //get the size of the fish
        if(name[i][0] == 'S') {
            width[i] = 20;
        }
        else if(name[i][0] == 'M') {
            width[i] = 30;
        }
        else if(name[i][0] == 'L') {
            width[i] = 45;
        }
    }
}
void Credits(userStats &user) {
    //declare variables for touch
    float x_position, y_position, x_trash, y_trash;
    //display developer names
    LCD.SetFontColor(WHITE);
    LCD.WriteAt("Developers", 94, 31);
    LCD.WriteAt("Evan Davis", 94, 91);
    LCD.WriteAt("JJ Kiratikosolrak", 60, 121);
    drawHome(280, 200);
    Sleep(.5);
    //clear touch buffer
    LCD.ClearBuffer();
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    //return to main menu
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        Menu(user);
    }
    else {
        Credits(user);
    }
}
void drawHome(int x, int y) {
    FEHImage home;
    home.Open("homeFEH.pic");
    home.Draw(x, y);
    home.Close();
}
void drawSetting(int x, int y) {
    FEHImage icon;
    icon.Open("settingFEH.pic");
    icon.Draw(x, y);
    icon.Close();
}
void drawReset(int x, int y) {
    FEHImage icon;
    icon.Open("resetFEH.pic");
    icon.Draw(x, y);
    icon.Close();
}
void setSettingScreen(userStats &user) {
    //declare variables for touch
    float x_position, y_position, x_trash, y_trash;
    //display developer names
    LCD.SetFontColor(WHITE);
    LCD.WriteAt("Setting", 101, 11);
    LCD.WriteAt("Delete Fish Collection", 40, 91);
    drawReset(15, 89);
    LCD.SetFontColor(WHITE);
    LCD.WriteAt("Reset Statistics", 70, 131);
    drawReset(45, 129);
    drawHome(280, 200);
    Sleep(.5);
    //clear touch buffer
    LCD.ClearBuffer();
    //wait till user touches the screen
    while(!LCD.Touch(&x_position, &y_position)) {}
    //wait until the touch releases
    while(LCD.Touch(&x_trash, &y_trash)) {}
    //return to main menu
    if((x_position >= 280 && x_position <= 300) && (y_position >= 200 && y_position <=220)) {
        Menu(user);
    }
    else if((x_position >= 15 && x_position <= 35) && (y_position >= 89 && y_position <=109)) {
        ofstream output;
        output.open("fishCaught.txt");
        output.close();
    }
    else if((x_position >= 45 && x_position <= 65) && (y_position >= 129 && y_position <=149)) {
        user.resetStats();
    }
    else {
        setSettingScreen(user);
    }
}
void ClearScreen() {
    // Clear background
    LCD.SetBackgroundColor(BLACK);
    LCD.Clear();
    LCD.Update();
    // LCD.SetFontColor(BLACK);
    // LCD.FillRectangle(0, 0, 319, 239);
    // LCD.SetFontColor(WHITE);
    // LCD.Update();
}
/*by Evan D. this function draws the instructions on the page and looks for user input to navigate to
another page or back to the main menu*/
void drawInstruction(int page){
    //print the instructions for the corresponding page. starts at y=30 and goes to y=165
    //i love no auto wraparound text!
    //15 pixel line spacing
    switch(page){
        case 1:
            LCD.WriteAt("To play, touch play on",10,30);
            LCD.WriteAt("the main menu. Your goal",10,45);
            LCD.WriteAt("is to guide the bobber to",10,60);
            LCD.WriteAt("a fish before the time",10,75);
            LCD.WriteAt("runs out or the bobber",10,90);
            LCD.WriteAt("reaches the bottom. You",10,105);
            LCD.WriteAt("will receive more money",10,120);
            LCD.WriteAt("depending on how much",10,135);
            LCD.WriteAt("the fish is worth. More",10,150);
            LCD.WriteAt("valuable fish are below.",10,165);
            LCD.WriteAt("1",145,195);
            break;
        case 2:
            LCD.WriteAt("You will accumulate money",10,30);
            LCD.WriteAt("over time, which can be",10,45);
            LCD.WriteAt("spent on various upgrades.",10,60);
            LCD.WriteAt("Upgrades increase the",10,75);
            LCD.WriteAt("speed of descent, the",10,90);
            LCD.WriteAt("horizontal speed, the",10,105);
            LCD.WriteAt("value of fish, and the",10,120);
            LCD.WriteAt("area you are in. Upgrades",10,135);
            LCD.WriteAt("get more expensive as",10,150);
            LCD.WriteAt("they are purchased.",10,165);
            LCD.WriteAt("2",145,195);
            break;
        case 3:
            LCD.WriteAt("Every unique fish that is",10,30);
            LCD.WriteAt("caught is added to a",10,45);
            LCD.WriteAt("collection which can be ",10,60);
            LCD.WriteAt("viewed from the menu.",10,75);
            LCD.WriteAt("Each fish has its own",10,90);
            LCD.WriteAt("entry with information",10,105);
            LCD.WriteAt("and facts about it.",10,120);
            LCD.WriteAt(" ",10,135);
            LCD.WriteAt(" ",10,150);
            LCD.WriteAt(" ",10,165);
            LCD.WriteAt("3",145,195);
            break;
    }
}
/*by Evan D. This function takes an integer input for a corresponding background image
1 is main menu background, 2 is sea/beach background, 3 is pond background, 4 is
river background*/
void drawBackground(int BGnum){
    FEHImage BG;
    switch(BGnum){
        case 0:
            BG.Open("mainFEH.pic");
            break;
        case 1:
            BG.Open("Pond-bgFEH.pic");
            break;
        case 2:
            BG.Open("River-bgFEH.pic");
            break;
        case 3:
            BG.Open("Beach-bgFEH.pic");
            break;
    }
    BG.Draw(0,0);
    BG.Close();
}
/* by Evan D and JJ K. Each drawFishRegion function takes 3 integer inputs, 1 for the fish image to draw and the other two are the coordinates to draw at.
The integers that correspond to fish are listed in each element of the switch case. */
void drawFishPond(char* pond,int x,int y){
    FEHImage Fish;
    Fish.Open(pond);
    Fish.Draw(x,y);
    Fish.Close();
}
void drawFishRiver(char* river, int x,int y){
    FEHImage Fish;
    Fish.Open(river);
    Fish.Draw(x,y);
    Fish.Close();
}
void drawFishSea(char* sea,int x,int y){
    FEHImage Fish;
    Fish.Open(sea);
    Fish.Draw(x,y);
    Fish.Close();
}
void drawArrow(int d, int x, int y) {
    //29 x 27
    FEHImage arrow;
    if(d == 1){
        arrow.Open("arrow-leftFEH.pic");
    }
    else if(d==2) {
        arrow.Open("arrow-rightFEH.pic");
    }
    arrow.Draw(x, y);
    arrow.Close();
}

bool checkFishCaught(int region, int fishNum) {
    ifstream fin;
    fin.open("fishCaught.txt");
    int r, num, caught = false;
    if(fin.is_open()) {
        while(fin.peek()!=EOF && !caught) {
            fin >> r >> num;
            if(r == region && num == fishNum) {
                caught = true;
            }
        }
    }
    fin.close();
    return caught;
}
void recordFishCaught(int region, int fishNum) {
    ofstream output;
    output.open("fishCaught.txt", ofstream::app);
    if(output.is_open()) {
        output << region << "\t" << fishNum << endl;
    }
    output.close();
}

void recordStats(userStats &user) {
    ofstream output;
    output.open("stats.txt");
    if(output.is_open()) {
        output << user.getMoney() << "\t" << user.getFishCaught() << "\t" << user.getDescentLevel() << "\t" << user.getHorizontalLevel() << "\t" << user.getValue();
    }
    output.close();
}

void resetStats(userStats &user) {
    user.resetStats();
}

int main() {
    // userStats user1;
    // recordStats(user1);
    ifstream fin;
    int m, f, d, h, v;
    fin.open("stats.txt");
    if(fin.is_open()) {
        //cout << "reading" << endl;
        fin >> m >> f >> d >> h >> v;
    }
    fin.close();
    //class holds users values
    userStats user1(m, f, d, h, v);
    userStats *user = &user1;
    // Clear background
    LCD.SetBackgroundColor(BLACK);
    LCD.Clear();
    Menu(*user);
    while (1) {
        LCD.Update();
        // Never end
    }
    return 0;
}

